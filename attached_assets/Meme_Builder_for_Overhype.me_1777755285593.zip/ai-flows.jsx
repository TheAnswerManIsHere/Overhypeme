// AI image gallery + generation, Video flow, Post-create

const { P: Pa, F: Fa, Hyped: Hya, PortraitBG: PGa } = window.OvTokens;
const { I: Ica, Shell: Sha, BottomSheet: BSa, PrimaryCTA: PCa, SecondaryCTA: SCa, HeaderBar: HBa, Avatar: Ava } = window.OvShell;
const { MemeCanvas: MCa } = window.OvStudio;
const { useState: uSa, useEffect: uEa } = React;

const VIBES = [
  {k:'cosmic', label:'Cosmic', desc:'Pushing galaxies'},
  {k:'galactic', label:'Galactic', desc:'Warm titan'},
  {k:'mythic', label:'Mythic', desc:'Heroic stance'},
  {k:'cyber', label:'Cyber', desc:'Neon overload'},
  {k:'storm', label:'Storm', desc:'Moody · cinematic'},
  {k:'gold', label:'Gold', desc:'Renaissance hero'},
];

// AI gallery — saved images, generate new
function AiGallery({fact, name, onClose, onPickImage, onGenerateNew, savedAi}) {
  return (
    <Sha>
      <HBa onBack={onClose} title="AI image studio" right={
        <button onClick={onGenerateNew} style={{padding:'8px 14px',background:Pa.primary,
          border:'none',borderRadius:999,color:'#fff',fontFamily:Fa.display,fontWeight:700,
          fontSize:11,letterSpacing:'0.14em',textTransform:'uppercase',cursor:'pointer',
          display:'flex',alignItems:'center',gap:6}}>
          <Ica k="plus" size={12} stroke={2.5}/> New
        </button>
      }/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        overflowY:'auto',padding:'0 16px 24px'}}>
        <div style={{padding:'4px 4px 14px'}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
            color:Pa.muted,fontFamily:Fa.display,textTransform:'uppercase',marginBottom:6}}>
            Memeing this fact
          </div>
          <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:18,
            textTransform:'uppercase',letterSpacing:'-0.005em',lineHeight:1.1}}>
            {fact.replace(/\{N\}/g, name).split(name).map((p,i,a)=>
              i<a.length-1 ? <React.Fragment key={i}>{p}<Hya>{name}</Hya></React.Fragment>
                : <React.Fragment key={i}>{p}</React.Fragment>)}
          </div>
        </div>

        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pa.muted,fontFamily:Fa.display,textTransform:'uppercase',marginBottom:10,marginLeft:4}}>
          Your AI images · {savedAi.length}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
          {/* New tile */}
          <button onClick={onGenerateNew} style={{
            aspectRatio:'1/1.15',background:Pa.card,
            border:`1.5px dashed ${Pa.primary}`,borderRadius:18,
            display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:8,
            cursor:'pointer',color:Pa.primary,
          }}>
            <div style={{width:40,height:40,borderRadius:20,background:Pa.primarySoft,
              display:'flex',alignItems:'center',justifyContent:'center'}}>
              <Ica k="sparkle" size={20} stroke={2.2}/>
            </div>
            <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:11,
              textTransform:'uppercase',letterSpacing:'0.12em'}}>
              Generate new
            </div>
          </button>
          {savedAi.map((img, i)=>(
            <button key={i} onClick={()=>onPickImage(img)} style={{
              aspectRatio:'1/1.15',position:'relative',
              border:'none',padding:0,borderRadius:18,overflow:'hidden',
              cursor:'pointer',background:Pa.card,
            }}>
              <PGa vibe={img.vibe}/>
              <div style={{position:'absolute',inset:0,
                background:'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.7) 100%)'}}/>
              <div style={{position:'absolute',top:8,left:8,padding:'3px 8px',borderRadius:999,
                background:'rgba(0,0,0,0.6)',backdropFilter:'blur(8px)',
                color:Pa.primary,fontSize:8,fontWeight:700,letterSpacing:'0.12em',
                fontFamily:Fa.display,display:'flex',alignItems:'center',gap:4}}>
                <Ica k="sparkle" size={9} stroke={2}/> {img.label}
              </div>
              <div style={{position:'absolute',bottom:8,left:8,right:8,
                fontFamily:Fa.body,fontSize:10,color:'#fff',fontWeight:500,textAlign:'left'}}>
                {img.when}
              </div>
            </button>
          ))}
        </div>

        {savedAi.length === 0 && (
          <div style={{textAlign:'center',padding:'40px 20px',color:Pa.muted,
            fontFamily:Fa.body,fontSize:13}}>
            No AI images yet. Tap <strong style={{color:Pa.primary}}>Generate new</strong> to make your first.
          </div>
        )}
      </div>
    </Sha>
  );
}

// AI generation screen — pick a vibe
function AiGenerate({fact, name, onClose, onGenerated, isLegendary}) {
  const [vibe, setVibe] = uSa('cosmic');
  const [prompt, setPrompt] = uSa('');
  const [generating, setGenerating] = uSa(false);
  const [progress, setProgress] = uSa(0);

  const handleGenerate = () => {
    setGenerating(true);
    setProgress(0);
    const iv = setInterval(()=>{
      setProgress(p=>{
        if (p>=100) { clearInterval(iv); setTimeout(()=>onGenerated({vibe, label:VIBES.find(v=>v.k===vibe).label, when:'Just now'}), 300); return 100; }
        return p + 6;
      });
    }, 80);
  };

  return (
    <Sha>
      <HBa onBack={onClose} title="Generate AI image"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        overflowY:'auto',padding:'0 16px 24px'}}>

        {/* Live preview of the chosen vibe */}
        <div style={{display:'flex',justifyContent:'center',padding:'8px 0 16px'}}>
          <div style={{width:240,height:300,borderRadius:18,overflow:'hidden',
            position:'relative',boxShadow:'0 12px 32px rgba(0,0,0,0.45)'}}>
            <PGa vibe={vibe}/>
            {generating && (
              <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,0.4)',
                display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:14}}>
                <div style={{width:48,height:48,borderRadius:24,
                  border:`3px solid ${Pa.hairlineStrong}`,borderTopColor:Pa.primary,
                  animation:'spin 0.8s linear infinite'}}/>
                <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:11,
                  letterSpacing:'0.18em',color:Pa.fg,textTransform:'uppercase'}}>
                  Dramatizing… {progress}%
                </div>
              </div>
            )}
          </div>
        </div>

        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pa.muted,fontFamily:Fa.display,textTransform:'uppercase',marginBottom:10}}>
          Pick a vibe
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3, 1fr)',gap:8,marginBottom:18}}>
          {VIBES.map(v=>{
            const active = vibe===v.k;
            return (
              <button key={v.k} onClick={()=>setVibe(v.k)} style={{
                padding:0,position:'relative',aspectRatio:'1/1.1',borderRadius:12,overflow:'hidden',
                border: active ? `2px solid ${Pa.primary}` : `1px solid ${Pa.hairlineStrong}`,
                cursor:'pointer',background:Pa.card,
              }}>
                <PGa vibe={v.k}/>
                <div style={{position:'absolute',inset:0,
                  background:'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.7) 100%)'}}/>
                <div style={{position:'absolute',bottom:6,left:6,right:6,textAlign:'left'}}>
                  <div style={{fontSize:10,fontWeight:700,fontFamily:Fa.display,color:'#fff',
                    letterSpacing:'0.04em',textTransform:'uppercase'}}>{v.label}</div>
                  <div style={{fontSize:8,color:'rgba(255,255,255,0.75)',fontFamily:Fa.body}}>{v.desc}</div>
                </div>
                {active && <div style={{position:'absolute',top:6,right:6,width:20,height:20,borderRadius:10,
                  background:Pa.primary,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff'}}>
                  <Ica k="check" size={11} stroke={3}/>
                </div>}
              </button>
            );
          })}
        </div>

        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pa.muted,fontFamily:Fa.display,textTransform:'uppercase',marginBottom:10}}>
          Optional: Tweak the scene
        </div>
        <textarea
          value={prompt} onChange={e=>setPrompt(e.target.value)}
          placeholder={`e.g. ${name} pushing the universe in a 70s tracksuit`}
          style={{
            width:'100%',minHeight:64,padding:14,
            background:Pa.card,border:`1px solid ${Pa.hairlineStrong}`,borderRadius:14,
            color:Pa.fg,fontSize:13,fontFamily:Fa.body,outline:'none',resize:'none',
            boxSizing:'border-box',marginBottom:14,
          }}
        />

        <div style={{padding:'10px 14px',background:Pa.primarySoft,borderRadius:12,
          marginBottom:16,display:'flex',alignItems:'center',gap:10,fontSize:12,
          color:Pa.fg2,fontFamily:Fa.body}}>
          <Ica k="sparkle" size={14} style={{color:Pa.primary,flexShrink:0}}/>
          <div>Will use your face. Tap <strong style={{color:Pa.fg}}>Generic</strong> below to skip your photo.</div>
        </div>

        <PCa onClick={handleGenerate} icon={<Ica k="sparkle" size={14} stroke={2.2}/>}>
          {generating ? `${progress}%` : 'Generate'}
        </PCa>
        <button style={{width:'100%',height:42,background:'transparent',color:Pa.muted,
          border:'none',marginTop:6,fontFamily:Fa.body,fontSize:12,cursor:'pointer'}}>
          Use generic faces instead
        </button>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </Sha>
  );
}

// Magic video — the one-shot fun path
function MagicVideo({fact, name, onClose, onDone}) {
  const [phase, setPhase] = uSa('generating'); // generating, done
  const [progress, setProgress] = uSa(0);
  const [stage, setStage] = uSa('Imagining the scene…');

  uEa(()=>{
    const iv = setInterval(()=>{
      setProgress(p=>{
        if (p>=100) { clearInterval(iv); setPhase('done'); return 100; }
        if (p===30) setStage('Generating AI image…');
        if (p===65) setStage('Animating the scene…');
        if (p===90) setStage('Adding the words…');
        return p + 2.5;
      });
    }, 80);
    return ()=>clearInterval(iv);
  }, []);

  return (
    <Sha>
      <HBa onBack={onClose} title="Magic video"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        overflowY:'auto',padding:'0 16px',
        display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center'}}>

        {phase==='generating' && (
          <>
            <div style={{width:280,height:350,borderRadius:18,overflow:'hidden',
              position:'relative',marginBottom:28,
              boxShadow:`0 20px 50px ${Pa.primaryGlow}`}}>
              <PGa vibe="cosmic"/>
              <div style={{position:'absolute',inset:0,
                background:'radial-gradient(circle at 50% 50%, transparent 30%, rgba(0,0,0,0.6) 100%)',
                display:'flex',alignItems:'center',justifyContent:'center'}}>
                <div style={{width:60,height:60,borderRadius:30,
                  border:`3px solid ${Pa.hairlineStrong}`,borderTopColor:Pa.primary,
                  animation:'spin 0.8s linear infinite'}}/>
              </div>
              {/* Progress bar */}
              <div style={{position:'absolute',bottom:0,left:0,right:0,height:4,
                background:Pa.hairlineStrong}}>
                <div style={{height:'100%',width:`${progress}%`,background:Pa.primary,
                  transition:'width 0.2s'}}/>
              </div>
            </div>
            <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:24,
              textTransform:'uppercase',letterSpacing:'-0.01em',marginBottom:8,textAlign:'center'}}>
              Making magic.
            </div>
            <div style={{fontSize:14,color:Pa.fg2,fontFamily:Fa.body,marginBottom:6}}>
              {stage}
            </div>
            <div style={{fontSize:11,color:Pa.muted,fontFamily:Fa.body,letterSpacing:'0.1em',
              fontWeight:600}}>
              {progress}% · ~{Math.max(1, Math.ceil((100-progress)/12))}s left
            </div>
          </>
        )}

        {phase==='done' && (
          <>
            <div style={{width:280,height:350,borderRadius:18,overflow:'hidden',
              position:'relative',marginBottom:20,
              boxShadow:`0 20px 50px ${Pa.primaryGlow}`}}>
              <PGa vibe="cosmic"/>
              <div style={{position:'absolute',inset:0,
                display:'flex',alignItems:'center',justifyContent:'center'}}>
                <div style={{width:64,height:64,borderRadius:32,background:'rgba(0,0,0,0.6)',
                  backdropFilter:'blur(10px)',
                  display:'flex',alignItems:'center',justifyContent:'center',color:'#fff'}}>
                  <Ica k="play" size={26} stroke={2}/>
                </div>
              </div>
              <div style={{position:'absolute',top:10,right:10,padding:'3px 8px',borderRadius:999,
                background:'rgba(0,0,0,0.6)',backdropFilter:'blur(8px)',
                color:Pa.fg,fontSize:9,fontWeight:600,fontFamily:Fa.body,letterSpacing:'0.04em'}}>
                0:04
              </div>
              <div style={{position:'absolute',bottom:14,left:14,right:14,
                fontFamily:Fa.display,fontWeight:700,fontSize:18,lineHeight:0.95,
                color:'#fff',textShadow:'0 2px 8px rgba(0,0,0,0.85)',
                textTransform:'uppercase',letterSpacing:'-0.01em'}}>
                The universe doesn't expand. <Hya>{name}</Hya> pushes it.
              </div>
            </div>
            <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:24,
              textTransform:'uppercase',letterSpacing:'-0.01em',marginBottom:14,textAlign:'center'}}>
              Done.
            </div>
            <div style={{width:'100%',maxWidth:320,paddingBottom:20}}>
              <PCa onClick={()=>onDone({type:'video',vibe:'cosmic'})}>
                Share it
              </PCa>
              <button style={{width:'100%',height:42,background:'transparent',color:Pa.fg2,
                border:'none',marginTop:8,fontFamily:Fa.body,fontSize:13,cursor:'pointer',
                display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
                <Ica k="refresh" size={14}/> Try again with a different vibe
              </button>
            </div>
          </>
        )}
      </div>
    </Sha>
  );
}

// Manual video — pick source, animation, length
function ManualVideo({fact, name, onClose, onDone, savedAi}) {
  const [source, setSource] = uSa(savedAi[0] || null);
  const [motion, setMotion] = uSa('zoom');
  const [length, setLength] = uSa(4);

  const motions = [
    {k:'zoom', label:'Zoom in', desc:'Subtle push'},
    {k:'parallax', label:'Parallax', desc:'Depth shift'},
    {k:'subject', label:'Subject moves', desc:'AI animates the person'},
    {k:'cinematic', label:'Cinematic', desc:'Camera arc'},
  ];

  return (
    <Sha>
      <HBa onBack={onClose} title="Manual video"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:90,
        overflowY:'auto',padding:'0 16px 24px'}}>

        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pa.muted,fontFamily:Fa.display,textTransform:'uppercase',marginBottom:10,marginTop:8}}>
          Source image
        </div>
        <div style={{display:'flex',gap:8,overflowX:'auto',paddingBottom:6,marginBottom:14}}>
          {savedAi.map((img,i)=>{
            const active = source && source.label===img.label;
            return (
              <button key={i} onClick={()=>setSource(img)} style={{
                width:80,height:96,borderRadius:12,position:'relative',
                border: active ? `2px solid ${Pa.primary}` : `1px solid ${Pa.hairlineStrong}`,
                padding:0,cursor:'pointer',overflow:'hidden',flexShrink:0,
              }}>
                <PGa vibe={img.vibe}/>
                <div style={{position:'absolute',bottom:4,left:4,right:4,
                  fontSize:8,fontFamily:Fa.display,fontWeight:700,color:'#fff',
                  letterSpacing:'0.06em',textTransform:'uppercase',textAlign:'left',
                  textShadow:'0 1px 2px rgba(0,0,0,0.8)'}}>{img.label}</div>
              </button>
            );
          })}
          <button style={{width:80,height:96,borderRadius:12,
            border:`1.5px dashed ${Pa.hairlineStrong}`,
            background:'transparent',cursor:'pointer',color:Pa.muted,
            display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:6,flexShrink:0}}>
            <Ica k="plus" size={18} stroke={2}/>
            <span style={{fontSize:9,fontFamily:Fa.body,fontWeight:600}}>New AI</span>
          </button>
        </div>

        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pa.muted,fontFamily:Fa.display,textTransform:'uppercase',marginBottom:10}}>
          Motion
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:18}}>
          {motions.map(m=>{
            const active = motion===m.k;
            return (
              <button key={m.k} onClick={()=>setMotion(m.k)} style={{
                padding:'12px 12px',background: active ? Pa.cardHi : Pa.card,
                border: active ? `1px solid ${Pa.primary}` : `1px solid ${Pa.hairlineStrong}`,
                borderRadius:12,cursor:'pointer',textAlign:'left',
              }}>
                <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:13,
                  textTransform:'uppercase',letterSpacing:'0.04em',color:Pa.fg}}>
                  {m.label}
                </div>
                <div style={{fontSize:11,color:Pa.muted,fontFamily:Fa.body,marginTop:2}}>
                  {m.desc}
                </div>
              </button>
            );
          })}
        </div>

        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pa.muted,fontFamily:Fa.display,textTransform:'uppercase',marginBottom:10}}>
          Length · {length}s
        </div>
        <div style={{padding:'8px 0 10px'}}>
          <input type="range" min="2" max="8" step="1" value={length}
            onChange={e=>setLength(parseInt(e.target.value))}
            style={{width:'100%',accentColor:Pa.primary}}/>
          <div style={{display:'flex',justifyContent:'space-between',fontSize:10,color:Pa.muted,
            fontFamily:Fa.body,marginTop:4}}>
            <span>2s</span><span>8s</span>
          </div>
        </div>
      </div>

      <div style={{position:'absolute',left:0,right:0,bottom:24,padding:'0 16px'}}>
        <PCa onClick={()=>onDone({type:'video',vibe:source?.vibe || 'cosmic'})}
          icon={<Ica k="video" size={14}/>}>
          Generate video
        </PCa>
      </div>
    </Sha>
  );
}

// Paywall sheet
function Paywall({reason, onClose, onUpgrade}) {
  const titles = {
    'ai': 'AI images are Legendary',
    'video': 'Videos are Legendary',
  };
  return (
    <Sha>
      <HBa onBack={onClose} title="Upgrade"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        padding:'0 20px 24px',display:'flex',flexDirection:'column'}}>

        {/* Triptych preview */}
        <div style={{display:'flex',gap:8,padding:'4px 0 18px',justifyContent:'center'}}>
          {['cosmic','galactic','mythic'].map((v,i)=>(
            <div key={v} style={{width:90,height:120,borderRadius:14,overflow:'hidden',
              position:'relative',
              transform: i===1 ? 'translateY(-10px) scale(1.06)' : 'translateY(0)',
              boxShadow:'0 12px 28px rgba(0,0,0,0.4)'}}>
              <PGa vibe={v}/>
              <div style={{position:'absolute',top:4,right:4,padding:'2px 6px',borderRadius:999,
                background:'rgba(0,0,0,0.6)',color:Pa.primary,fontSize:7,fontWeight:700,
                letterSpacing:'0.12em',fontFamily:Fa.display}}>AI</div>
            </div>
          ))}
        </div>

        <div style={{padding:'2px 8px 4px',borderRadius:6,background:Pa.primarySoft,
          color:Pa.primary,fontSize:10,fontWeight:700,letterSpacing:'0.16em',fontFamily:Fa.display,
          textTransform:'uppercase',alignSelf:'flex-start',marginBottom:10}}>
          👑 LEGENDARY
        </div>
        <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:30,
          textTransform:'uppercase',letterSpacing:'-0.015em',lineHeight:0.98,marginBottom:8}}>
          {titles[reason]}
        </div>
        <div style={{fontSize:14,color:Pa.fg2,fontFamily:Fa.body,marginBottom:18,lineHeight:1.4}}>
          AI dramatizes facts about you — generated images and short videos of you as the literal subject.
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:20}}>
          {[
            'Unlimited AI images',
            'AI video generation',
            'Magic video — one-tap fun',
            'Print on premium merch',
          ].map((b,i)=>(
            <div key={i} style={{display:'flex',alignItems:'center',gap:10,fontSize:13,
              color:Pa.fg,fontFamily:Fa.body}}>
              <div style={{width:18,height:18,borderRadius:9,background:Pa.primarySoft,
                display:'flex',alignItems:'center',justifyContent:'center',color:Pa.primary,flexShrink:0}}>
                <Ica k="check" size={11} stroke={3}/>
              </div>
              {b}
            </div>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:14}}>
          <div style={{padding:14,borderRadius:14,background:Pa.card,
            border:`1px solid ${Pa.hairlineStrong}`}}>
            <div style={{fontSize:10,fontWeight:700,color:Pa.muted,letterSpacing:'0.1em',
              fontFamily:Fa.display,textTransform:'uppercase',marginBottom:4}}>Monthly</div>
            <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:22,lineHeight:1}}>
              $4.99<span style={{fontSize:11,color:Pa.muted,fontWeight:500}}>/mo</span>
            </div>
          </div>
          <div style={{padding:14,borderRadius:14,background:Pa.card,
            border:`2px solid ${Pa.primary}`,position:'relative'}}>
            <div style={{position:'absolute',top:-8,right:10,padding:'2px 8px',borderRadius:999,
              background:Pa.primary,color:'#fff',fontSize:8,fontWeight:700,letterSpacing:'0.12em',
              fontFamily:Fa.display,textTransform:'uppercase'}}>Best</div>
            <div style={{fontSize:10,fontWeight:700,color:Pa.primary,letterSpacing:'0.1em',
              fontFamily:Fa.display,textTransform:'uppercase',marginBottom:4}}>Forever</div>
            <div style={{fontFamily:Fa.display,fontWeight:700,fontSize:22,lineHeight:1}}>
              $39<span style={{fontSize:11,color:Pa.muted,fontWeight:500}}> once</span>
            </div>
          </div>
        </div>
        <PCa onClick={onUpgrade}>Get Legendary</PCa>
      </div>
    </Sha>
  );
}

window.OvAi = { AiGallery, AiGenerate, MagicVideo, ManualVideo, Paywall, VIBES };
