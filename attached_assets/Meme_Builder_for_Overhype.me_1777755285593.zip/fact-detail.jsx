// Fact detail screen — entry point that takes user into Make Meme

const { P: Pt, F: Ft, Hyped: Hy, Wordmark: WM } = window.OvTokens;
const { I: Ic, Avatar: Av, Shell: Sh, PrimaryCTA: PC, HeaderBar: HB } = window.OvShell;

function FactDetail({fact, name, onMakeMeme, onClose}) {
  return (
    <Sh>
      <HB onBack={onClose} title="Fact"
        right={<button style={{width:36,height:36,borderRadius:18,background:'transparent',
          border:'none',color:Pt.fg,cursor:'pointer',display:'flex',alignItems:'center',
          justifyContent:'center'}}><Ic k="more" size={20}/></button>}/>

      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,overflowY:'auto',paddingBottom:120}}>
        <div style={{padding:'8px 24px 24px'}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:18}}>
            <div style={{padding:'4px 10px',borderRadius:999,background:Pt.primarySoft,
              color:Pt.primary,fontSize:10,fontWeight:700,letterSpacing:'0.18em',
              fontFamily:Ft.display,textTransform:'uppercase'}}>HALL OF FAME · #1</div>
          </div>
          <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:38,
            textTransform:'uppercase',letterSpacing:'-0.02em',lineHeight:0.98,marginBottom:18}}>
            {fact.replace(/\{N\}/g, name).split(name).map((p,i,a)=>
              i<a.length-1 ? <React.Fragment key={i}>{p}<Hy>{name}</Hy></React.Fragment>
                : <React.Fragment key={i}>{p}</React.Fragment>)}
          </div>

          <div style={{display:'flex',alignItems:'center',gap:14,fontSize:13,color:Pt.fg2,marginBottom:24}}>
            <div style={{display:'flex',alignItems:'center',gap:6}}>
              <Av name={name} size={24}/>
              <span>{name}</span>
            </div>
            <span style={{color:Pt.muted}}>·</span>
            <span>12.8k 🔥</span>
            <span style={{color:Pt.muted}}>·</span>
            <span>432 💬</span>
          </div>

          <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:8}}>
            {['#physics','#cosmic','#origin'].map(t=>(
              <div key={t} style={{padding:'6px 12px',borderRadius:999,
                background:Pt.card,border:`1px solid ${Pt.hairlineStrong}`,
                fontSize:12,color:Pt.fg,fontWeight:500}}>{t}</div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky bottom CTA */}
      <div style={{position:'absolute',left:0,right:0,bottom:0,padding:'14px 16px 30px',
        background:`linear-gradient(180deg, transparent 0%, ${Pt.bg} 30%)`,zIndex:5}}>
        <PC onClick={onMakeMeme} icon={<Ic k="sparkle" size={16}/>}>Make a meme</PC>
      </div>
    </Sh>
  );
}

window.OvFactDetail = { FactDetail };
