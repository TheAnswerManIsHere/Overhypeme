// Post-create share + merch screens

const { P: Pp, F: Fp, Hyped: Hyp, PortraitBG: PGp } = window.OvTokens;
const { I: Icp, Shell: Shp, BottomSheet: BSp, PrimaryCTA: PCp, SecondaryCTA: SCp, HeaderBar: HBp } = window.OvShell;
const { useState: uSp } = React;

// Share + merch — for image memes
function PostImage({fact, name, source, ratio, wordPos, wordStyle, onClose, onMakeAnother, onMerch}) {
  const { MemeCanvas } = window.OvStudio;

  return (
    <Shp>
      <HBp onBack={onClose} title="Share" right={
        <button style={{padding:'8px 12px',background:'transparent',border:'none',
          color:Pp.fg2,fontFamily:Fp.body,fontSize:13,fontWeight:600,cursor:'pointer'}}>
          Done
        </button>
      }/>

      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        overflowY:'auto',padding:'0 16px 24px'}}>

        {/* Saved indicator */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:8,
          padding:'4px 0 14px',color:Pp.success,fontFamily:Fp.body,fontSize:13,fontWeight:600}}>
          <div style={{width:18,height:18,borderRadius:9,background:Pp.success,
            display:'flex',alignItems:'center',justifyContent:'center'}}>
            <Icp k="check" size={11} stroke={3} style={{color:'#000'}}/>
          </div>
          Meme saved
        </div>

        {/* Centered preview */}
        <div style={{display:'flex',justifyContent:'center',marginBottom:20}}>
          <MemeCanvas fact={fact} name={name} ratio={ratio || '1:1'} source={source}
            wordStyle={wordStyle || 'classic'} wordPos={wordPos || 'bottom'} scale={0.78}/>
        </div>

        {/* Share row — platform-specific */}
        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pp.muted,fontFamily:Fp.display,textTransform:'uppercase',marginBottom:10,marginLeft:4}}>
          Share to
        </div>
        <div style={{display:'flex',gap:10,overflowX:'auto',paddingBottom:6,marginBottom:18}}>
          {[
            {l:'Instagram',c:'linear-gradient(135deg,#833AB4,#FD1D1D,#FCB045)',sub:'Story'},
            {l:'TikTok',c:'#000',sub:'Post'},
            {l:'Twitter',c:'#0F0F0F',sub:'Post'},
            {l:'iMessage',c:'#34C759',sub:'Send'},
            {l:'Save',c:Pp.card,sub:'Camera roll'},
            {l:'More',c:Pp.card,sub:''},
          ].map(s=>(
            <button key={s.l} style={{
              minWidth:72,padding:'10px 8px',background:'transparent',
              border:'none',cursor:'pointer',color:Pp.fg,
              display:'flex',flexDirection:'column',alignItems:'center',gap:6,flexShrink:0}}>
              <div style={{width:48,height:48,borderRadius:14,background:s.c,
                display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',
                fontFamily:Fp.display,fontWeight:700,fontSize:14,
                border: s.c===Pp.card ? `1px solid ${Pp.hairlineStrong}` : 'none'}}>
                {s.l[0]}
              </div>
              <div style={{fontSize:11,fontFamily:Fp.body,fontWeight:600}}>{s.l}</div>
              {s.sub && <div style={{fontSize:9,color:Pp.muted,fontFamily:Fp.body,marginTop:-3}}>{s.sub}</div>}
            </button>
          ))}
        </div>

        {/* Merch — preview-driven */}
        <div onClick={onMerch} style={{padding:'14px',borderRadius:18,background:Pp.card,
          border:`1px solid ${Pp.hairlineStrong}`,cursor:'pointer',marginBottom:10,
          display:'flex',gap:14,alignItems:'center'}}>
          {/* T-shirt mock */}
          <div style={{width:80,height:80,borderRadius:12,background:'#0a0a0a',
            position:'relative',overflow:'hidden',flexShrink:0}}>
            <div style={{position:'absolute',inset:'18% 14% 14% 14%',
              borderRadius:'45% 45% 12% 12% / 12% 12% 12% 12%',
              background:'#222',
              boxShadow:'inset 0 -10px 14px rgba(0,0,0,0.5)'}}/>
            <div style={{position:'absolute',top:'30%',left:'30%',right:'30%',height:'40%',
              background:'#fff',display:'flex',alignItems:'center',justifyContent:'center',
              fontFamily:Fp.display,fontWeight:700,fontSize:7,color:'#000',
              textAlign:'center',lineHeight:1,padding:2,textTransform:'uppercase'}}>
              {name.toUpperCase()} pushes the universe
            </div>
          </div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:2}}>
              <Icp k="shop" size={14}/>
              <div style={{fontFamily:Fp.display,fontWeight:700,fontSize:13,
                textTransform:'uppercase',letterSpacing:'0.06em'}}>
                Wear this meme
              </div>
            </div>
            <div style={{fontSize:12,color:Pp.muted,fontFamily:Fp.body}}>
              Tee · hoodie · sticker · more
            </div>
            <div style={{fontSize:11,color:Pp.primary,fontFamily:Fp.body,fontWeight:600,marginTop:4}}>
              From $22 →
            </div>
          </div>
        </div>

        {/* Make another */}
        <button onClick={onMakeAnother} style={{width:'100%',padding:'14px',
          background:Pp.card,border:`1px solid ${Pp.hairlineStrong}`,borderRadius:18,
          cursor:'pointer',color:Pp.fg,
          display:'flex',gap:14,alignItems:'center'}}>
          <div style={{width:44,height:44,borderRadius:12,background:Pp.primarySoft,
            display:'flex',alignItems:'center',justifyContent:'center',color:Pp.primary,flexShrink:0}}>
            <Icp k="refresh" size={20}/>
          </div>
          <div style={{flex:1,textAlign:'left'}}>
            <div style={{fontFamily:Fp.display,fontWeight:700,fontSize:13,
              textTransform:'uppercase',letterSpacing:'0.06em'}}>
              Another from this fact
            </div>
            <div style={{fontSize:12,color:Pp.muted,fontFamily:Fp.body,marginTop:1}}>
              Try a different vibe or layout
            </div>
          </div>
          <Icp k="back" size={16} style={{transform:'rotate(180deg)',color:Pp.muted}}/>
        </button>
      </div>
    </Shp>
  );
}

// Post — video version (no merch)
function PostVideo({name, vibe='cosmic', onClose, onMakeAnother}) {
  return (
    <Shp>
      <HBp onBack={onClose} title="Share"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        overflowY:'auto',padding:'0 16px 24px'}}>

        <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:8,
          padding:'4px 0 14px',color:Pp.success,fontFamily:Fp.body,fontSize:13,fontWeight:600}}>
          <div style={{width:18,height:18,borderRadius:9,background:Pp.success,
            display:'flex',alignItems:'center',justifyContent:'center'}}>
            <Icp k="check" size={11} stroke={3} style={{color:'#000'}}/>
          </div>
          Video saved
        </div>

        <div style={{display:'flex',justifyContent:'center',marginBottom:20}}>
          <div style={{width:240,height:300,borderRadius:18,overflow:'hidden',
            position:'relative',boxShadow:`0 16px 40px rgba(0,0,0,0.5)`}}>
            <PGp vibe={vibe}/>
            <div style={{position:'absolute',inset:0,
              display:'flex',alignItems:'center',justifyContent:'center'}}>
              <div style={{width:54,height:54,borderRadius:27,background:'rgba(0,0,0,0.55)',
                backdropFilter:'blur(10px)',
                display:'flex',alignItems:'center',justifyContent:'center',color:'#fff'}}>
                <Icp k="play" size={22} stroke={2}/>
              </div>
            </div>
            <div style={{position:'absolute',bottom:14,left:14,right:14,
              fontFamily:Fp.display,fontWeight:700,fontSize:16,lineHeight:0.95,
              color:'#fff',textShadow:'0 2px 8px rgba(0,0,0,0.85)',
              textTransform:'uppercase',letterSpacing:'-0.01em'}}>
              The universe doesn't expand. <Hyp>{name}</Hyp> pushes it.
            </div>
            <div style={{position:'absolute',top:10,left:10,padding:'3px 8px',borderRadius:999,
              background:'rgba(0,0,0,0.6)',backdropFilter:'blur(8px)',
              color:Pp.primary,fontSize:8,fontWeight:700,letterSpacing:'0.12em',
              fontFamily:Fp.display,display:'flex',alignItems:'center',gap:4}}>
              <Icp k="video" size={9} stroke={2}/> AI VIDEO
            </div>
          </div>
        </div>

        <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
          color:Pp.muted,fontFamily:Fp.display,textTransform:'uppercase',marginBottom:10,marginLeft:4}}>
          Share to
        </div>
        <div style={{display:'flex',gap:10,overflowX:'auto',paddingBottom:6,marginBottom:18}}>
          {[
            {l:'TikTok',c:'#000'},
            {l:'Instagram',c:'linear-gradient(135deg,#833AB4,#FD1D1D,#FCB045)'},
            {l:'Reels',c:'#1306DC'},
            {l:'iMessage',c:'#34C759'},
            {l:'Save',c:Pp.card},
            {l:'More',c:Pp.card},
          ].map(s=>(
            <button key={s.l} style={{
              minWidth:72,padding:'10px 8px',background:'transparent',
              border:'none',cursor:'pointer',color:Pp.fg,
              display:'flex',flexDirection:'column',alignItems:'center',gap:6,flexShrink:0}}>
              <div style={{width:48,height:48,borderRadius:14,background:s.c,
                display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',
                fontFamily:Fp.display,fontWeight:700,fontSize:14,
                border: s.c===Pp.card ? `1px solid ${Pp.hairlineStrong}` : 'none'}}>
                {s.l[0]}
              </div>
              <div style={{fontSize:11,fontFamily:Fp.body,fontWeight:600}}>{s.l}</div>
            </button>
          ))}
        </div>

        <button onClick={onMakeAnother} style={{width:'100%',padding:'14px',
          background:Pp.card,border:`1px solid ${Pp.hairlineStrong}`,borderRadius:18,
          cursor:'pointer',color:Pp.fg,
          display:'flex',gap:14,alignItems:'center'}}>
          <div style={{width:44,height:44,borderRadius:12,background:Pp.primarySoft,
            display:'flex',alignItems:'center',justifyContent:'center',color:Pp.primary,flexShrink:0}}>
            <Icp k="refresh" size={20}/>
          </div>
          <div style={{flex:1,textAlign:'left'}}>
            <div style={{fontFamily:Fp.display,fontWeight:700,fontSize:13,
              textTransform:'uppercase',letterSpacing:'0.06em'}}>
              Make another
            </div>
            <div style={{fontSize:12,color:Pp.muted,fontFamily:Fp.body,marginTop:1}}>
              Image meme · different vibe
            </div>
          </div>
          <Icp k="back" size={16} style={{transform:'rotate(180deg)',color:Pp.muted}}/>
        </button>
      </div>
    </Shp>
  );
}

// Fact detail — entry point. Not the focus, but needed so the prototype is navigable.
function FactDetail({fact, name, onMakeMeme, onClose}) {
  return (
    <Shp>
      <HBp onBack={onClose} title="Fact"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:96,
        padding:'8px 20px 20px',overflowY:'auto'}}>

        <div style={{fontSize:11,fontWeight:700,letterSpacing:'0.18em',
          color:Pp.muted,fontFamily:Fp.display,textTransform:'uppercase',marginBottom:14,
          display:'flex',alignItems:'center',gap:8}}>
          <span style={{width:24,height:1,background:Pp.muted,opacity:0.5}}/>
          ABOUT {name.toUpperCase()}
        </div>

        <h1 style={{fontFamily:Fp.display,fontWeight:700,fontSize:42,
          lineHeight:0.98,textTransform:'uppercase',letterSpacing:'-0.02em',margin:0,
          marginBottom:24,textWrap:'pretty'}}>
          {fact.replace(/\{N\}/g, name).split(name).map((p,i,a)=>
            i<a.length-1 ? <React.Fragment key={i}>{p}<Hyp>{name}</Hyp></React.Fragment>
              : <React.Fragment key={i}>{p}</React.Fragment>)}
        </h1>

        <div style={{display:'flex',gap:14,marginBottom:24,fontSize:12,color:Pp.fg2,fontFamily:Fp.body}}>
          <span><strong style={{color:Pp.fg}}>12.8k</strong> ▲</span>
          <span><strong style={{color:Pp.fg}}>432</strong> 💬</span>
          <span style={{color:Pp.muted}}>· #physics #cosmic</span>
        </div>

        <div style={{padding:14,background:Pp.card,borderRadius:14,
          border:`1px solid ${Pp.hairline}`,display:'flex',gap:10,alignItems:'flex-start',
          fontSize:13,color:Pp.fg2,fontFamily:Fp.body,lineHeight:1.4}}>
          <Icp k="sparkle" size={16} style={{color:Pp.primary,flexShrink:0,marginTop:2}}/>
          <div>
            Make this fact <strong style={{color:Pp.fg}}>about you, visually</strong>.
            One tap → AI dramatizes it. Or use your own photo.
          </div>
        </div>
      </div>

      <div style={{position:'absolute',left:0,right:0,bottom:24,padding:'0 20px'}}>
        <PCp onClick={onMakeMeme} icon={<Icp k="sparkle" size={14} stroke={2.2}/>}>
          Make a meme
        </PCp>
      </div>
    </Shp>
  );
}

window.OvPost = { PostImage, PostVideo, FactDetail };
