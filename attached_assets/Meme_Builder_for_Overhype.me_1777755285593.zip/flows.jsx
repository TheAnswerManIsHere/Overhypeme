// Overhype.me — Flows: AI gallery, editor, video, post-create

const { P: Pt, F: Ft, Hyped: Hy, PortraitBG: PG } = window.OvTokens;
const { I: Ic, Chip: Ch, Shell: Sh, BottomSheet: BS, PrimaryCTA: PC, SecondaryCTA: SC, HeaderBar: HB } = window.OvShell;
const { MemeCanvas: MC, RATIOS: RT, WORD_STYLES: WS } = window.OvStudio;
const { useState: uS, useEffect: uE } = React;

// AI library data
const AI_IMAGES = [
  {id:1, vibe:'cosmic', prompt:'Pushing the universe', new:true},
  {id:2, vibe:'galactic', prompt:'Slap heard worldwide'},
  {id:3, vibe:'mythic', prompt:'Time freeze stance'},
  {id:4, vibe:'cyber', prompt:'Wi-Fi origin moment'},
  {id:5, vibe:'gold', prompt:'Cover-confessing pose'},
];

// AI GALLERY ─────────────────────────────────────────────────
function AIGallery({fact, name, onClose, onPick, generating, onGenerate}) {
  const [vibe, setVibe] = uS('cosmic');
  const vibes = [
    {k:'cosmic',label:'Cosmic'},{k:'galactic',label:'Epic'},
    {k:'mythic',label:'Mythic'},{k:'cyber',label:'Cyber'},
    {k:'gold',label:'Royal'},{k:'storm',label:'Noir'},
  ];

  return (
    <Sh>
      <HB onBack={onClose} title="AI image"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,overflowY:'auto',paddingBottom:30}}>
        <div style={{padding:'4px 20px 14px'}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
            color:Pt.muted,fontFamily:Ft.display,textTransform:'uppercase',marginBottom:6}}>
            About {name}
          </div>
          <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:20,
            textTransform:'uppercase',letterSpacing:'-0.01em',lineHeight:1.05}}>
            {fact.replace(/\{N\}/g, name).split(name).map((p,i,a)=>
              i<a.length-1 ? <React.Fragment key={i}>{p}<Hy>{name}</Hy></React.Fragment>
                : <React.Fragment key={i}>{p}</React.Fragment>)}
          </div>
        </div>

        <div style={{padding:'0 16px 12px'}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:Pt.muted,
            fontFamily:Ft.display,textTransform:'uppercase',marginBottom:8}}>Style</div>
          <div style={{display:'flex',gap:6,overflowX:'auto',paddingBottom:4}}>
            {vibes.map(v => <Ch key={v.k} active={vibe===v.k} onClick={()=>setVibe(v.k)}>{v.label}</Ch>)}
          </div>
        </div>

        <div style={{padding:'0 16px 14px'}}>
          <PC onClick={onGenerate} disabled={generating}
            icon={<Ic k="sparkle" size={16}/>}>
            {generating ? 'Generating…' : `Generate ${vibe} version`}
          </PC>
          <div style={{textAlign:'center',marginTop:6,fontSize:11,color:Pt.muted}}>
            ~15 seconds · 1 of 30 this month
          </div>
        </div>

        <div style={{padding:'4px 16px'}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:Pt.muted,
            fontFamily:Ft.display,textTransform:'uppercase',marginBottom:10}}>
            Your AI library · {AI_IMAGES.length}
          </div>

          {generating && (
            <div style={{borderRadius:14,background:Pt.card,padding:14,marginBottom:10,
              border:`1px solid ${Pt.hairlineStrong}`,display:'flex',alignItems:'center',gap:12}}>
              <div style={{width:56,height:56,borderRadius:10,background:Pt.bg2,
                display:'flex',alignItems:'center',justifyContent:'center',
                position:'relative',overflow:'hidden'}}>
                <div style={{position:'absolute',inset:0,
                  background:`linear-gradient(90deg, transparent, ${Pt.primarySoft}, transparent)`,
                  animation:'shimmer 1.5s infinite'}}/>
                <Ic k="sparkle" size={18} style={{color:Pt.primary,zIndex:1}}/>
              </div>
              <div style={{flex:1}}>
                <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:13,
                  textTransform:'uppercase',letterSpacing:'0.06em'}}>Generating {vibe}…</div>
                <div style={{fontSize:11,color:Pt.muted,marginTop:2}}>About 12s left</div>
              </div>
            </div>
          )}

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
            {AI_IMAGES.map(img => (
              <button key={img.id} onClick={()=>onPick(img)} style={{
                padding:0,border:'none',background:'transparent',cursor:'pointer',
                position:'relative',borderRadius:14,overflow:'hidden',aspectRatio:'1/1.2',
              }}>
                <PG vibe={img.vibe}/>
                {img.new && (
                  <div style={{position:'absolute',top:8,left:8,padding:'3px 8px',borderRadius:999,
                    background:Pt.primary,color:'#fff',fontSize:9,fontWeight:700,
                    letterSpacing:'0.12em',fontFamily:Ft.display,zIndex:2}}>NEW</div>
                )}
                <div style={{position:'absolute',inset:0,
                  background:'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.7))'}}/>
                <div style={{position:'absolute',left:8,right:8,bottom:8,zIndex:2,textAlign:'left'}}>
                  <div style={{fontSize:10,fontFamily:Ft.display,fontWeight:700,
                    color:Pt.primary,letterSpacing:'0.1em',textTransform:'uppercase'}}>{img.vibe}</div>
                  <div style={{fontSize:10,color:'rgba(255,255,255,0.85)',
                    marginTop:2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                    {img.prompt}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </Sh>
  );
}

// IMAGE EDITOR ────────────────────────────────────────────────
function ImageEditor({fact, name, source, onClose, onSave}) {
  const [ratio, setRatio] = uS('1:1');
  const [wordStyle, setWordStyle] = uS('classic');
  const [wordPos, setWordPos] = uS('bottom');
  const [showAdvanced, setShowAdvanced] = uS(false);
  const [showSwap, setShowSwap] = uS(false);

  return (
    <Sh bg="#000">
      <HB onBack={onClose} title="Editor"
        right={<button onClick={onSave} style={{padding:'8px 14px',borderRadius:18,
          background:Pt.primary,color:'#fff',border:'none',
          fontFamily:Ft.display,fontWeight:700,fontSize:11,letterSpacing:'0.14em',
          textTransform:'uppercase',cursor:'pointer'}}>Save</button>}/>

      <div style={{position:'absolute',top:98,left:0,right:0,bottom:230,
        display:'flex',alignItems:'center',justifyContent:'center',padding:'0 12px'}}>
        <MC fact={fact} name={name} ratio={ratio} source={source}
          wordStyle={wordStyle} wordPos={wordPos}
          scale={ratio==='9:16' ? 0.65 : (ratio==='16:9' ? 1 : 0.9)}/>
      </div>

      {/* Source swap pill, top-right floating */}
      <button onClick={()=>setShowSwap(true)} style={{
        position:'absolute',top:108,right:14,zIndex:6,
        padding:'6px 12px',borderRadius:999,
        background:'rgba(0,0,0,0.6)',backdropFilter:'blur(8px)',
        border:`1px solid ${Pt.hairlineStrong}`,color:Pt.fg,
        fontFamily:Ft.body,fontSize:11,fontWeight:600,
        display:'flex',alignItems:'center',gap:5,cursor:'pointer',
      }}>
        <Ic k="refresh" size={12}/> Swap source
      </button>

      <div style={{position:'absolute',left:0,right:0,bottom:0,
        background:Pt.bg,borderTop:`1px solid ${Pt.hairline}`,padding:'12px 0 26px'}}>

        <div style={{padding:'0 16px 8px'}}>
          <div style={{fontSize:9,fontWeight:700,letterSpacing:'0.18em',color:Pt.muted,
            fontFamily:Ft.display,textTransform:'uppercase',marginBottom:6}}>Shape</div>
          <div style={{display:'flex',gap:6,overflowX:'auto'}}>
            {RT.map(r => (
              <Ch key={r.k} active={ratio===r.k} onClick={()=>setRatio(r.k)}>
                <span style={{display:'inline-block',
                  width: r.w >= r.h ? 14 : 14*r.w/r.h,
                  height: r.h >= r.w ? 10 : 10*r.h/r.w,
                  border:'1.5px solid currentColor',borderRadius:2,marginRight:4,
                  verticalAlign:'middle'}}/>
                {r.k}
              </Ch>
            ))}
          </div>
        </div>

        <div style={{padding:'4px 16px 8px'}}>
          <div style={{fontSize:9,fontWeight:700,letterSpacing:'0.18em',color:Pt.muted,
            fontFamily:Ft.display,textTransform:'uppercase',marginBottom:6}}>Words</div>
          <div style={{display:'flex',gap:6,overflowX:'auto'}}>
            {WS.map(w => <Ch key={w.k} active={wordStyle===w.k} onClick={()=>setWordStyle(w.k)}>{w.label}</Ch>)}
          </div>
        </div>

        <div style={{padding:'4px 16px 0',display:'flex',gap:8}}>
          <button onClick={()=>setWordPos(wordPos==='bottom'?'top':'bottom')}
            style={{flex:1,padding:'10px 12px',borderRadius:12,
              background:Pt.card,border:`1px solid ${Pt.hairlineStrong}`,
              color:Pt.fg,cursor:'pointer',
              display:'flex',alignItems:'center',justifyContent:'center',gap:6,
              fontFamily:Ft.body,fontSize:12,fontWeight:600}}>
            <Ic k="move" size={14}/> {wordPos==='bottom'?'Top':'Bottom'}
          </button>
          <button onClick={()=>setShowAdvanced(true)}
            style={{flex:1,padding:'10px 12px',borderRadius:12,
              background:Pt.card,border:`1px solid ${Pt.hairlineStrong}`,
              color:Pt.fg,cursor:'pointer',
              display:'flex',alignItems:'center',justifyContent:'center',gap:6,
              fontFamily:Ft.body,fontSize:12,fontWeight:600}}>
            <Ic k="type" size={14}/> Tweak words
          </button>
        </div>
      </div>

      {showAdvanced && (
        <BS onClose={()=>setShowAdvanced(false)}>
          <div style={{padding:'8px 20px 36px'}}>
            <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:18,
              textTransform:'uppercase',letterSpacing:'0.04em',marginBottom:14}}>
              Advanced
            </div>
            {[
              {l:'Font', s:'Oswald (default)'},{l:'Size', s:'Auto · 28pt'},
              {l:'Color', s:'White'},{l:'Stroke', s:'None'},{l:'Shadow', s:'Soft'},
              {l:'Drag to position', s:'Tap & hold on canvas'},
            ].map((it,i)=>(
              <div key={i} style={{padding:'14px 0',borderBottom:`1px solid ${Pt.hairline}`,
                display:'flex',alignItems:'center'}}>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:600}}>{it.l}</div>
                  <div style={{fontSize:11,color:Pt.muted,marginTop:2}}>{it.s}</div>
                </div>
                <Ic k="back" size={16} style={{transform:'rotate(180deg)',color:Pt.muted}}/>
              </div>
            ))}
          </div>
        </BS>
      )}

      {showSwap && (
        <BS onClose={()=>setShowSwap(false)}>
          <div style={{padding:'8px 20px 36px'}}>
            <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:18,
              textTransform:'uppercase',letterSpacing:'0.04em',marginBottom:14}}>
              Swap background
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              {[
                {k:'photo',label:'Your photo',vibe:'photo'},
                {k:'ai',label:'AI image',vibe:'cosmic'},
                {k:'stock',label:'Stock',vibe:'storm'},
                {k:'gradient',label:'Color',vibe:'gold'},
              ].map(s => (
                <button key={s.k} onClick={()=>setShowSwap(false)} style={{
                  padding:0,border:'none',background:Pt.card,borderRadius:14,
                  overflow:'hidden',cursor:'pointer',color:Pt.fg,position:'relative',
                  aspectRatio:'1/1'}}>
                  <PG vibe={s.vibe}/>
                  <div style={{position:'absolute',inset:0,
                    background:'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.75))'}}/>
                  <div style={{position:'absolute',left:8,right:8,bottom:8,fontFamily:Ft.display,
                    fontWeight:700,fontSize:13,textTransform:'uppercase',letterSpacing:'0.04em',
                    color:'#fff',textAlign:'left'}}>
                    {s.label}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </BS>
      )}
    </Sh>
  );
}

// VIDEO FLOW ──────────────────────────────────────────────────
function VideoFlow({fact, name, mode='magic', onClose, onDone}) {
  const [step, setStep] = uS(mode==='magic' ? 'generating' : 'pick-source');
  const [progress, setProgress] = uS(0);

  uE(()=>{
    if (step !== 'generating' && step !== 'animating') return;
    const t = setInterval(()=>{
      setProgress(p => {
        const next = p + 5;
        if (next >= 100) {
          clearInterval(t);
          setTimeout(onDone, 500);
          return 100;
        }
        return next;
      });
    }, 250);
    return ()=>clearInterval(t);
  }, [step, onDone]);

  if (step === 'pick-source') {
    return (
      <Sh>
        <HB onBack={onClose} title="Manual video"/>
        <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,padding:'8px 16px',overflowY:'auto'}}>
          <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:24,
            textTransform:'uppercase',letterSpacing:'-0.01em',marginBottom:6}}>
            Pick a source
          </div>
          <div style={{fontSize:13,color:Pt.fg2,marginBottom:18}}>
            Step 1 of 2 · We'll animate it next.
          </div>

          {[
            {k:'ai',label:'From AI library',sub:'5 saved · best results',vibe:'cosmic',rec:true},
            {k:'photo',label:'Your photo',sub:'Upload or camera roll',vibe:'photo'},
            {k:'stock',label:'Stock photo',sub:'Pre-made backgrounds',vibe:'storm'},
          ].map(s => (
            <button key={s.k} onClick={()=>setStep('animating')} style={{
              width:'100%',padding:'14px',marginBottom:10,
              background:Pt.card,
              border: s.rec ? `1px solid ${Pt.primary}` : `1px solid ${Pt.hairlineStrong}`,
              borderRadius:18,cursor:'pointer',color:Pt.fg,
              display:'flex',alignItems:'center',gap:14,textAlign:'left',position:'relative',
            }}>
              <div style={{width:64,height:80,borderRadius:10,overflow:'hidden',position:'relative',flexShrink:0}}>
                <PG vibe={s.vibe}/>
              </div>
              <div style={{flex:1}}>
                <div style={{display:'flex',alignItems:'center',gap:6}}>
                  <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:15,
                    textTransform:'uppercase',letterSpacing:'0.04em'}}>{s.label}</div>
                  {s.rec && <div style={{padding:'2px 6px',borderRadius:6,background:Pt.primarySoft,
                    color:Pt.primary,fontSize:8,fontWeight:700,letterSpacing:'0.12em',
                    fontFamily:Ft.display}}>BEST</div>}
                </div>
                <div style={{fontSize:12,color:Pt.fg2,marginTop:2}}>{s.sub}</div>
              </div>
              <Ic k="back" size={18} style={{transform:'rotate(180deg)',color:Pt.muted}}/>
            </button>
          ))}
        </div>
      </Sh>
    );
  }

  return (
    <Sh>
      <HB onBack={onClose} title={mode==='magic'?'Magic video':'Animating'}/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:24}}>
        <div style={{width:240,height:300,borderRadius:18,overflow:'hidden',
          position:'relative',marginBottom:24,
          boxShadow:`0 12px 32px ${Pt.primaryGlow}`}}>
          <PG vibe="cosmic"/>
          <div style={{position:'absolute',inset:0,
            background:`linear-gradient(90deg, transparent, ${Pt.primarySoft}, transparent)`,
            animation:'shimmer 2s infinite'}}/>
          <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center'}}>
            <Ic k="sparkle" size={48} style={{color:Pt.primary}}/>
          </div>
        </div>
        <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:22,
          textTransform:'uppercase',letterSpacing:'-0.01em',marginBottom:6,textAlign:'center'}}>
          {mode==='magic' ? <>Conjuring <Hy>{name}</Hy>…</> : 'Animating frames…'}
        </div>
        <div style={{fontSize:13,color:Pt.fg2,marginBottom:20,textAlign:'center'}}>
          {mode==='magic'
            ? 'Generating AI scene → animating motion'
            : `About ${Math.round((100-progress)/3)}s left`}
        </div>
        <div style={{width:240,height:4,borderRadius:2,background:Pt.card,overflow:'hidden'}}>
          <div style={{width:`${progress}%`,height:'100%',background:Pt.primary,transition:'width 0.2s'}}/>
        </div>
        <div style={{marginTop:8,fontSize:11,color:Pt.muted}}>{progress}%</div>
      </div>
    </Sh>
  );
}

// PAYWALL ─────────────────────────────────────────────────────
function Paywall({reason='ai', onClose, onUnlock}) {
  const isVideo = reason === 'video';
  return (
    <Sh>
      <HB onBack={onClose} title="Legendary"/>
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,overflowY:'auto',padding:'8px 20px 30px'}}>
        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:14}}>
          <div style={{padding:'4px 10px',borderRadius:999,background:Pt.primarySoft,
            color:Pt.primary,fontSize:10,fontWeight:700,letterSpacing:'0.16em',
            fontFamily:Ft.display,textTransform:'uppercase'}}>👑 Legendary</div>
        </div>
        <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:32,
          textTransform:'uppercase',letterSpacing:'-0.015em',lineHeight:0.98,marginBottom:8}}>
          {isVideo ? <>Animated. Iconic. <Hy>You.</Hy></> : <>Become the <Hy>fact.</Hy></>}
        </div>
        <div style={{fontSize:14,color:Pt.fg2,marginBottom:20,lineHeight:1.4}}>
          {isVideo
            ? 'AI animates the scene — short shareable videos of you doing the impossible.'
            : 'AI dramatizes the fact — pick a vibe, get a one-of-a-kind image of you as the subject.'}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8,marginBottom:18}}>
          {['cosmic','galactic','mythic'].map(v => (
            <div key={v} style={{aspectRatio:'1/1.25',borderRadius:14,overflow:'hidden',position:'relative'}}>
              <PG vibe={v}/>
            </div>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:14}}>
          <div style={{padding:14,borderRadius:14,background:Pt.card,border:`1px solid ${Pt.hairlineStrong}`}}>
            <div style={{fontSize:10,fontWeight:700,color:Pt.muted,letterSpacing:'0.1em',
              fontFamily:Ft.display,textTransform:'uppercase',marginBottom:4}}>Monthly</div>
            <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:24,lineHeight:1}}>
              $4.99<span style={{fontSize:12,color:Pt.muted,fontWeight:500}}>/mo</span>
            </div>
            <div style={{fontSize:11,color:Pt.fg2,marginTop:6}}>30 AI generations</div>
          </div>
          <div style={{padding:14,borderRadius:14,background:Pt.card,border:`2px solid ${Pt.primary}`,position:'relative'}}>
            <div style={{position:'absolute',top:-8,right:10,padding:'2px 8px',borderRadius:999,
              background:Pt.primary,color:'#fff',fontSize:9,fontWeight:700,letterSpacing:'0.12em',
              fontFamily:Ft.display,textTransform:'uppercase'}}>Best</div>
            <div style={{fontSize:10,fontWeight:700,color:Pt.primary,letterSpacing:'0.1em',
              fontFamily:Ft.display,textTransform:'uppercase',marginBottom:4}}>Forever</div>
            <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:24,lineHeight:1}}>
              $39<span style={{fontSize:12,color:Pt.muted,fontWeight:500}}> once</span>
            </div>
            <div style={{fontSize:11,color:Pt.fg2,marginTop:6}}>Unlimited</div>
          </div>
        </div>

        <PC onClick={onUnlock} icon={<Ic k="sparkle" size={16}/>}>Go Legendary</PC>
        <button onClick={onClose} style={{width:'100%',height:42,background:'transparent',
          color:Pt.muted,border:'none',marginTop:6,fontFamily:Ft.body,fontSize:13,cursor:'pointer'}}>
          Maybe later
        </button>
      </div>
    </Sh>
  );
}

// POST-CREATE ─────────────────────────────────────────────────
function PostCreate({fact, name, source, kind='image', onClose, onMakeAnother, onMerch}) {
  return (
    <Sh>
      <HB onBack={onClose} title={kind==='image' ? 'Image saved' : 'Video saved'}
        right={<button onClick={onClose} style={{padding:'8px 14px',background:'transparent',
          color:Pt.muted,border:'none',fontFamily:Ft.body,fontSize:13,fontWeight:600,
          cursor:'pointer'}}>Done</button>}/>

      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,overflowY:'auto',paddingBottom:30}}>
        <div style={{padding:'8px 24px 18px',display:'flex',justifyContent:'center'}}>
          <div style={{position:'relative'}}>
            <MC fact={fact} name={name} ratio="1:1" source={source}
              wordStyle="classic" wordPos="bottom" scale={0.82}/>
            {kind === 'video' && (
              <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',
                pointerEvents:'none'}}>
                <div style={{width:56,height:56,borderRadius:28,background:'rgba(0,0,0,0.55)',
                  backdropFilter:'blur(8px)',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff'}}>
                  <Ic k="play" size={22}/>
                </div>
              </div>
            )}
            <div style={{position:'absolute',top:-8,right:-8,padding:'4px 10px',borderRadius:999,
              background:Pt.success,color:'#000',fontSize:10,fontWeight:700,letterSpacing:'0.14em',
              fontFamily:Ft.display,display:'flex',alignItems:'center',gap:4}}>
              <Ic k="check" size={11} stroke={2.4}/> SAVED
            </div>
          </div>
        </div>

        <div style={{padding:'4px 16px 14px'}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:Pt.muted,
            fontFamily:Ft.display,textTransform:'uppercase',marginBottom:10,paddingLeft:4}}>
            Share to
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4, 1fr)',gap:8}}>
            {[
              {k:'ig',label:'Instagram',c:'#E1306C',sub:'Story'},
              {k:'tt',label:'TikTok',c:'#000',sub:kind==='video'?'Video':'Post'},
              {k:'x',label:'X',c:'#000',sub:'Post'},
              {k:'wa',label:'WhatsApp',c:'#25D366',sub:'Status'},
            ].map(s => (
              <button key={s.k} style={{
                background:Pt.card,border:`1px solid ${Pt.hairlineStrong}`,
                borderRadius:14,padding:'12px 6px',cursor:'pointer',color:Pt.fg,
                display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                <div style={{width:30,height:30,borderRadius:8,background:s.c,
                  display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',
                  fontSize:13,fontWeight:700,fontFamily:Ft.display}}>{s.label[0]}</div>
                <div style={{fontSize:10,fontWeight:600}}>{s.label}</div>
                <div style={{fontSize:9,color:Pt.muted}}>{s.sub}</div>
              </button>
            ))}
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginTop:8}}>
            <SC icon={<Ic k="download" size={15}/>}>Save</SC>
            <SC icon={<Ic k="share" size={15}/>}>More</SC>
          </div>
        </div>

        {kind === 'image' && (
          <div style={{padding:'8px 16px 14px'}}>
            <button onClick={onMerch} style={{
              width:'100%',padding:'14px',background:Pt.card,
              border:`1px solid ${Pt.hairlineStrong}`,borderRadius:18,
              cursor:'pointer',color:Pt.fg,display:'flex',alignItems:'center',gap:14,textAlign:'left'}}>
              <div style={{width:60,height:60,borderRadius:10,
                background:'#fff',display:'flex',alignItems:'center',justifyContent:'center',
                position:'relative',overflow:'hidden',flexShrink:0}}>
                <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:8,
                  color:'#000',textAlign:'center',lineHeight:1,
                  textTransform:'uppercase',padding:4}}>
                  {name.toUpperCase()}<br/>WAS HERE
                </div>
              </div>
              <div style={{flex:1}}>
                <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:14,
                  textTransform:'uppercase',letterSpacing:'0.04em'}}>Wear this meme</div>
                <div style={{fontSize:12,color:Pt.fg2,marginTop:2}}>Tee, hoodie, sticker · from $22</div>
              </div>
              <Ic k="back" size={16} style={{transform:'rotate(180deg)',color:Pt.muted}}/>
            </button>
          </div>
        )}

        <div style={{padding:'8px 16px'}}>
          <button onClick={onMakeAnother} style={{
            width:'100%',padding:'14px',background:'transparent',
            border:`1px dashed ${Pt.hairlineStrong}`,borderRadius:18,
            cursor:'pointer',color:Pt.fg,display:'flex',alignItems:'center',gap:12,textAlign:'left'}}>
            <div style={{width:36,height:36,borderRadius:18,background:Pt.primarySoft,
              display:'flex',alignItems:'center',justifyContent:'center',color:Pt.primary,flexShrink:0}}>
              <Ic k="plus" size={18}/>
            </div>
            <div style={{flex:1}}>
              <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:13,
                textTransform:'uppercase',letterSpacing:'0.04em'}}>Make another from this fact</div>
              <div style={{fontSize:11,color:Pt.muted,marginTop:2}}>
                {kind==='image' ? 'Try the video version' : 'Try a different vibe'}
              </div>
            </div>
            <Ic k="back" size={16} style={{transform:'rotate(180deg)',color:Pt.muted}}/>
          </button>
        </div>
      </div>
    </Sh>
  );
}

window.OvFlows = { AIGallery, ImageEditor, VideoFlow, Paywall, PostCreate };
