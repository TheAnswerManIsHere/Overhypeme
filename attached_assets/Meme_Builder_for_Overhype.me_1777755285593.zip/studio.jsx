// Meme Studio — the core canvas. Smart-defaults first, power tools on tap.

const { P: Pt, F: Ft, FACE_GRADS: FG, Hyped: Hy, FlameMark: FM, Wordmark: WM, PortraitBG: PG } = window.OvTokens;
const { Avatar: Av, I: Ic, Chip: Ch, Shell: Sh, BottomSheet: BS, PrimaryCTA: PC, SecondaryCTA: SC, HeaderBar: HB } = window.OvShell;
const { useState: uS, useRef: uR, useEffect: uE } = React;

// Aspect ratios — what user can pick
const RATIOS = [
  {k:'1:1', label:'Square', w:1, h:1},
  {k:'4:5', label:'Portrait', w:4, h:5},
  {k:'9:16', label:'Story', w:9, h:16},
  {k:'16:9', label:'Wide', w:16, h:9},
];

// Background sources
const BG_SOURCES = [
  {k:'photo', label:'Your photo', icon:'camera', tone:0},
  {k:'ai', label:'AI image', icon:'sparkle', vibe:'cosmic', locked:true},
  {k:'stock', label:'Stock', icon:'image', vibe:'storm'},
  {k:'gradient', label:'Color', icon:'image', vibe:'gold'},
];

// Word style presets — picked by smart-default
const WORD_STYLES = [
  {k:'classic', label:'Classic', font:Ft.display, size:28, color:'#fff', shadow:'0 2px 12px rgba(0,0,0,0.85)', stroke:'none', bg:'none'},
  {k:'tabloid', label:'Tabloid', font:Ft.display, size:32, color:'#fff', shadow:'none', stroke:'2px #000', bg:'none'},
  {k:'block', label:'Block', font:Ft.display, size:26, color:'#000', shadow:'none', stroke:'none', bg:'#fff'},
  {k:'neon', label:'Neon', font:Ft.display, size:28, color:'#fff', shadow:`0 0 20px ${Pt.primary}, 0 0 40px ${Pt.primary}`, stroke:'none', bg:'none'},
];

// ─── The render of the meme itself ──
function MemeCanvas({fact, name, ratio, source, wordStyle, wordPos, scale=1, showBadges=true}) {
  const r = RATIOS.find(x=>x.k===ratio) || RATIOS[0];
  const aspect = r.w / r.h;
  // Container width is fixed; height derives
  const containerW = 320 * scale;
  const containerH = containerW / aspect;

  const ws = WORD_STYLES.find(x=>x.k===wordStyle) || WORD_STYLES[0];
  const renderedFact = fact.replace(/\{N\}/g, name);
  const parts = renderedFact.split(name);

  // Smart-positioned word block — `wordPos` is 'top' | 'bottom' | 'split'
  const positionStyles = {
    bottom: {bottom: '8%', top: 'auto', left: '6%', right: '6%'},
    top: {top: '8%', bottom: 'auto', left: '6%', right: '6%'},
    split: {bottom: '8%', top: 'auto', left: '6%', right: '6%'}, // simplified
  };

  return (
    <div style={{
      width:containerW,height:containerH,position:'relative',
      borderRadius:18,overflow:'hidden',
      boxShadow:'0 12px 32px rgba(0,0,0,0.45)',
    }}>
      <PG tone={source?.tone ?? 0} vibe={source?.vibe ?? 'photo'}/>
      {/* Word overlay */}
      <div style={{position:'absolute',
        ...positionStyles[wordPos || 'bottom'],
        textAlign:'left',pointerEvents:'none',
      }}>
        <h1 style={{
          fontFamily: ws.font, fontWeight:700,
          fontSize: ws.size * scale, lineHeight:0.95,
          textTransform:'uppercase',
          letterSpacing:'-0.015em',
          margin:0,
          color: ws.color,
          textShadow: ws.shadow,
          WebkitTextStroke: ws.stroke === 'none' ? '0' : ws.stroke,
          background: ws.bg !== 'none' ? ws.bg : 'transparent',
          padding: ws.bg !== 'none' ? '6px 10px' : 0,
          display: ws.bg !== 'none' ? 'inline-block' : 'block',
          textWrap: 'pretty',
        }}>
          {parts.map((p,i)=> i<parts.length-1
            ? <React.Fragment key={i}>{p}<span style={{color:Pt.primary}}>{name}</span></React.Fragment>
            : <React.Fragment key={i}>{p}</React.Fragment>)}
        </h1>
      </div>

      {/* AI badge */}
      {showBadges && source?.k === 'ai' && (
        <div style={{position:'absolute',top:10,left:10,padding:'4px 10px',borderRadius:999,
          background:'rgba(0,0,0,0.6)',backdropFilter:'blur(8px)',
          color:Pt.primary,fontSize:9,fontWeight:700,letterSpacing:'0.16em',
          fontFamily:Ft.display,display:'flex',alignItems:'center',gap:4}}>
          <Ic k="sparkle" size={10} stroke={2}/> AI
        </div>
      )}
    </div>
  );
}

// ─── Studio: the new entry point ──
// Lands here when user taps "Make a meme" from a fact detail.
// Shows: live preview top, big Magic CTA + alt sources below.
function StudioEntry({fact, name, onPickPath, onClose, isLegendary, defaultMode='photo'}) {
  // defaultMode: 'photo' = your photo first; 'ai' = AI promoted as the hero CTA
  const aiFirst = defaultMode === 'ai';

  return (
    <Sh>
      <HB onBack={onClose} title="Make a meme"/>

      <div style={{position:'absolute',top:98,left:0,right:0,bottom:0,
        overflowY:'auto',paddingBottom:20}}>

        {/* Fact echo */}
        <div style={{padding:'4px 20px 12px'}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
            color:Pt.muted,fontFamily:Ft.display,textTransform:'uppercase',marginBottom:6}}>
            Your fact
          </div>
          <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:22,
            textTransform:'uppercase',letterSpacing:'-0.01em',lineHeight:1.05}}>
            {fact.replace(/\{N\}/g, name).split(name).map((p,i,a)=>
              i<a.length-1 ? <React.Fragment key={i}>{p}<Hy>{name}</Hy></React.Fragment>
                : <React.Fragment key={i}>{p}</React.Fragment>)}
          </div>
        </div>

        {/* HERO card — the recommended path */}
        <div style={{padding:'8px 16px 14px'}}>
          <div onClick={()=>onPickPath(aiFirst ? 'ai-image' : 'photo-image')} style={{
            position:'relative',borderRadius:24,overflow:'hidden',
            background: aiFirst
              ? `linear-gradient(135deg, ${Pt.primary} 0%, #c0392b 100%)`
              : Pt.card,
            border: aiFirst ? 'none' : `1px solid ${Pt.hairlineStrong}`,
            cursor:'pointer',
            boxShadow: aiFirst ? `0 12px 32px ${Pt.primaryGlow}` : 'none',
          }}>
            {/* Preview */}
            <div style={{padding:'14px 14px 0',display:'flex',justifyContent:'center'}}>
              <MemeCanvas
                fact={fact} name={name}
                ratio="1:1"
                source={aiFirst ? {k:'ai',vibe:'cosmic'} : {k:'photo',tone:0}}
                wordStyle="classic" wordPos="bottom" scale={0.78}
                showBadges={!aiFirst}
              />
            </div>
            <div style={{padding:'14px 18px 18px',color: aiFirst ? '#fff' : Pt.fg}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                {aiFirst && <Ic k="sparkle" size={14} stroke={2.2}/>}
                <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:11,
                  letterSpacing:'0.18em',textTransform:'uppercase',
                  opacity: aiFirst ? 1 : 0.6}}>
                  {aiFirst ? '✨ Recommended · AI' : 'Photo meme'}
                </div>
              </div>
              <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:24,
                textTransform:'uppercase',letterSpacing:'-0.01em',lineHeight:1,marginBottom:8}}>
                {aiFirst
                  ? <>See <Hy>you</Hy> doing the impossible.</>
                  : <>Use your photo</>
                }
              </div>
              <div style={{fontSize:13, opacity: aiFirst ? 0.92 : 0.7,
                fontFamily:Ft.body,lineHeight:1.4}}>
                {aiFirst
                  ? `AI dramatizes the fact — ${name} as the literal subject.`
                  : 'Drop your face on it. Words snap into place.'}
              </div>
            </div>
          </div>
        </div>

        {/* Magic Video — single-tap one-shot for fun */}
        <div style={{padding:'0 16px 10px'}}>
          <button onClick={()=>onPickPath(isLegendary ? 'magic-video' : 'paywall-video')}
            style={{width:'100%',padding:'14px 16px',
            background: Pt.card, border:`1px solid ${Pt.hairlineStrong}`,
            borderRadius:18,
            display:'flex',alignItems:'center',gap:14,cursor:'pointer',color:Pt.fg,
            position:'relative',overflow:'hidden',
          }}>
            <div style={{width:48,height:48,borderRadius:14,
              background:`linear-gradient(135deg, ${Pt.primary}, #c0392b)`,
              display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',
              flexShrink:0}}>
              <Ic k="wand" size={22} stroke={2.2}/>
            </div>
            <div style={{flex:1,textAlign:'left',minWidth:0}}>
              <div style={{display:'flex',alignItems:'center',gap:6}}>
                <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:15,
                  textTransform:'uppercase',letterSpacing:'0.04em'}}>
                  Magic video
                </div>
                {!isLegendary && (
                  <div style={{padding:'2px 6px',borderRadius:6,background:Pt.primarySoft,
                    color:Pt.primary,fontSize:8,fontWeight:700,letterSpacing:'0.12em',
                    fontFamily:Ft.display}}>
                    LEGENDARY
                  </div>
                )}
              </div>
              <div style={{fontSize:12,color:Pt.fg2,fontFamily:Ft.body,marginTop:2}}>
                One tap → AI scene → animated video of you
              </div>
            </div>
            <Ic k="back" size={18} style={{transform:'rotate(180deg)',color:Pt.muted}}/>
          </button>
        </div>

        {/* Quieter alts: split or sources */}
        <div style={{padding:'8px 16px 0'}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
            color:Pt.muted,fontFamily:Ft.display,textTransform:'uppercase',
            margin:'12px 4px 10px'}}>
            Other ways
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
            <AltCard label={aiFirst ? 'Photo meme' : 'AI image'}
              icon={aiFirst ? 'camera' : 'sparkle'}
              sub={aiFirst ? 'Use your camera roll' : 'Generate a scene'}
              locked={!aiFirst && !isLegendary}
              onClick={()=>onPickPath(aiFirst ? 'photo-image' : (isLegendary ? 'ai-gallery' : 'paywall-ai'))}/>
            <AltCard label="Manual video"
              icon="video"
              sub="Pick source · animate"
              locked={!isLegendary}
              onClick={()=>onPickPath(isLegendary ? 'manual-video' : 'paywall-video')}/>
            <AltCard label="Stock photo"
              icon="image"
              sub="Pre-made backgrounds"
              onClick={()=>onPickPath('stock-image')}/>
            <AltCard label="Color"
              icon="image"
              sub="Gradient or solid"
              onClick={()=>onPickPath('gradient-image')}/>
          </div>
        </div>

        <div style={{height:24}}/>
      </div>
    </Sh>
  );
}

const AltCard = ({label, icon, sub, locked, onClick}) => (
  <button onClick={onClick} style={{
    padding:'14px 14px',background:Pt.card,
    border:`1px solid ${Pt.hairlineStrong}`,borderRadius:16,
    cursor:'pointer',color:Pt.fg,textAlign:'left',
    display:'flex',flexDirection:'column',gap:8,
    position:'relative',
  }}>
    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
      <div style={{width:32,height:32,borderRadius:10,background:Pt.bg2,
        display:'flex',alignItems:'center',justifyContent:'center',color:Pt.fg2}}>
        <Ic k={icon} size={16}/>
      </div>
      {locked && <Ic k="lock" size={12} style={{color:Pt.amber}}/>}
    </div>
    <div>
      <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:13,
        textTransform:'uppercase',letterSpacing:'0.04em'}}>{label}</div>
      <div style={{fontSize:11,color:Pt.muted,fontFamily:Ft.body,marginTop:2}}>{sub}</div>
    </div>
  </button>
);

window.OvStudio = { MemeCanvas, StudioEntry, RATIOS, BG_SOURCES, WORD_STYLES };
