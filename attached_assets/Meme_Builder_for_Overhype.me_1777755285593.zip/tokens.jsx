// Overhype.me — design tokens lifted from system

const P = {
  bg: '#0F0F11',
  bg2: '#16161A',
  card: '#1C1A1D',
  cardHi: '#252227',
  hairline: 'rgba(255,255,255,0.06)',
  hairlineStrong: 'rgba(255,255,255,0.10)',
  fg: '#FAFAFA',
  fg2: '#C7C7CC',
  muted: '#86868B',
  primary: '#FF6500',
  primarySoft: 'rgba(255,101,0,0.14)',
  primaryGlow: 'rgba(255,101,0,0.32)',
  success: '#34C759',
  amber: '#FFB800',
};

const F = {
  display: "'Oswald', 'Impact', 'Helvetica Neue Condensed', sans-serif",
  body: "'Inter', -apple-system, BlinkMacSystemFont, 'Helvetica Neue', sans-serif",
};

// FACE photos — simple SVG stand-ins so the UX is real even without uploads
const FACE_GRADS = [
  'radial-gradient(circle at 50% 38%, #d9b290 0%, #9a7355 60%, #4a3422 100%)',
  'radial-gradient(circle at 48% 42%, #f4c4a0 0%, #b8835c 55%, #5a3a20 100%)',
  'radial-gradient(circle at 52% 36%, #c89878 0%, #8a5a3a 65%, #3a2010 100%)',
];

const Hyped = ({children}) => (
  <span style={{color:P.primary}}>{children}</span>
);

const FlameMark = ({size=16,color=P.primary}) => (
  <svg width={size} height={size*1.25} viewBox="0 0 16 20" fill="none">
    <path d="M8 1c1 4 5 5 5 10s-2.5 8-5 8-5-3-5-8c0-4 2-5 3-7 0 2 1 3 2 3z" fill={color}/>
  </svg>
);

const Wordmark = ({size=15}) => (
  <div style={{display:'flex',alignItems:'center',gap:6,fontFamily:F.display,
    fontWeight:700,fontSize:size,letterSpacing:'0.04em',color:P.fg,textTransform:'uppercase'}}>
    <FlameMark size={size}/>
    <span>OVERHYPE<span style={{color:P.primary}}>.ME</span></span>
  </div>
);

// Photographic placeholder — uses CSS to fake a portrait
const PortraitBG = ({tone=0, vibe='photo', children, opacity=1}) => {
  const grads = {
    photo: FACE_GRADS[tone],
    cosmic: 'radial-gradient(ellipse at 50% 35%, #6b3aa8 0%, #2a1454 40%, #050010 100%)',
    galactic: 'radial-gradient(ellipse at 45% 40%, #ff6b3a 0%, #8a2a14 35%, #1a0a05 100%)',
    mythic: 'radial-gradient(ellipse at 55% 38%, #3a8aff 0%, #1a3a8a 40%, #050a1a 100%)',
    cyber: 'linear-gradient(135deg, #ff00aa 0%, #00aaff 50%, #1a0a3a 100%)',
    storm: 'radial-gradient(ellipse at 30% 30%, #4a4a6a 0%, #1a1a2a 50%, #050505 100%)',
    gold: 'radial-gradient(ellipse at 50% 30%, #ffd700 0%, #b8860b 40%, #2a1f00 100%)',
  };
  return (
    <div style={{position:'absolute',inset:0,background:grads[vibe] || grads.photo, opacity}}>
      {/* face silhouette to fake a portrait */}
      <div style={{position:'absolute',left:'25%',right:'25%',top:'18%',bottom:'12%',
        borderRadius:'50% 50% 45% 45% / 60% 60% 40% 40%',
        background: vibe === 'photo'
          ? 'radial-gradient(circle at 50% 38%, rgba(255,220,180,0.6), rgba(120,80,50,0.4) 70%)'
          : 'radial-gradient(circle at 50% 38%, rgba(255,255,255,0.4), rgba(0,0,0,0.2) 70%)',
        filter: 'blur(0.5px)'}}/>
      {vibe !== 'photo' && (
        <div style={{position:'absolute',inset:0,
          backgroundImage:'radial-gradient(1.5px 1.5px at 20% 25%, #fffc, transparent), radial-gradient(1px 1px at 75% 55%, #fffa, transparent), radial-gradient(1.2px 1.2px at 45% 78%, #fff8, transparent), radial-gradient(1px 1px at 85% 20%, #fff9, transparent), radial-gradient(1px 1px at 15% 70%, #fff7, transparent)'}}/>
      )}
      {children}
    </div>
  );
};

window.OvTokens = { P, F, FACE_GRADS, Hyped, FlameMark, Wordmark, PortraitBG };
