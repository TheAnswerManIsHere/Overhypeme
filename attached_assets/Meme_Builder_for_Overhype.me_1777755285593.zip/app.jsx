// Overhype.me — Meme builder redesign — main app

const { P: Pt, F: Ft } = window.OvTokens;
const { useState } = React;
const { FactDetail } = window.OvFactDetail;
const { StudioEntry } = window.OvStudio;
const { AIGallery, ImageEditor, VideoFlow, Paywall, PostCreate } = window.OvFlows;
const { DStudioEntry, DEditor, DAIGallery, DPostCreate } = window.OvDesktopMeme;

const FACT = "The universe doesn't expand. {N} pushes it.";

const TWEAKS = /*EDITMODE-BEGIN*/{
  "name": "Riley",
  "defaultMode": "ai",
  "isLegendary": false,
  "entryPattern": "hub"
}/*EDITMODE-END*/;

const FRAME_W = 390, FRAME_H = 844;

function PhoneFrame({children, label}) {
  return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:10}}>
      {label && <div style={{fontFamily:Ft.display,fontWeight:700,fontSize:11,
        letterSpacing:'0.18em',textTransform:'uppercase',color:'#666'}}>{label}</div>}
      <div style={{position:'relative',width:FRAME_W,height:FRAME_H,
        background:'#000',borderRadius:54,overflow:'hidden',
        border:'10px solid #1a1a1a',
        boxShadow:'0 30px 60px -20px rgba(0,0,0,0.4), 0 0 0 2px #2a2a2a inset'}}>
        <div style={{position:'absolute',top:11,left:'50%',transform:'translateX(-50%)',
          width:120,height:32,background:'#000',borderRadius:20,zIndex:200}}/>
        {children}
      </div>
    </div>
  );
}

// Each artboard is a self-contained mini-flow rooted at a starting screen.
function MiniFlow({startScreen, name, defaultMode, isLegendary: lg0}) {
  const [screen, setScreen] = useState(startScreen);
  const [editorSource, setEditorSource] = useState({k:'photo',tone:0});
  const [postKind, setPostKind] = useState('image');
  const [generating, setGenerating] = useState(false);
  const [isLegendary, setIsLegendary] = useState(lg0);

  const goStudio = () => setScreen('studio');
  const goFact = () => setScreen('fact');

  const handleStudioPick = (path) => {
    if (path === 'photo-image' || path === 'stock-image' || path === 'gradient-image') {
      const sources = {
        'photo-image': {k:'photo',tone:0},
        'stock-image': {k:'stock',vibe:'storm'},
        'gradient-image': {k:'gradient',vibe:'gold'},
      };
      setEditorSource(sources[path]);
      setScreen('editor');
    } else if (path === 'ai-image' || path === 'ai-gallery') {
      if (!isLegendary) setScreen('paywall-ai');
      else setScreen('ai-gallery');
    } else if (path === 'magic-video') {
      if (!isLegendary) setScreen('paywall-video');
      else setScreen('magic-video');
    } else if (path === 'manual-video') {
      if (!isLegendary) setScreen('paywall-video');
      else setScreen('manual-video');
    } else if (path === 'paywall-ai') {
      setScreen('paywall-ai');
    } else if (path === 'paywall-video') {
      setScreen('paywall-video');
    }
  };

  if (screen === 'fact') {
    return <FactDetail fact={FACT} name={name}
      onMakeMeme={goStudio} onClose={()=>{}}/>;
  }
  if (screen === 'studio') {
    return <StudioEntry fact={FACT} name={name} isLegendary={isLegendary}
      defaultMode={defaultMode}
      onPickPath={handleStudioPick} onClose={goFact}/>;
  }
  if (screen === 'ai-gallery') {
    return <AIGallery fact={FACT} name={name} generating={generating}
      onGenerate={()=>{
        setGenerating(true);
        setTimeout(()=>setGenerating(false), 4000);
      }}
      onPick={(img)=>{
        setEditorSource({k:'ai',vibe:img.vibe});
        setScreen('editor');
      }}
      onClose={goStudio}/>;
  }
  if (screen === 'editor') {
    return <ImageEditor fact={FACT} name={name} source={editorSource}
      onClose={goStudio}
      onSave={()=>{
        setPostKind('image');
        setScreen('post');
      }}/>;
  }
  if (screen === 'magic-video' || screen === 'manual-video') {
    return <VideoFlow fact={FACT} name={name}
      mode={screen==='magic-video' ? 'magic' : 'manual'}
      onClose={goStudio}
      onDone={()=>{
        setEditorSource({k:'ai',vibe:'cosmic'});
        setPostKind('video');
        setScreen('post');
      }}/>;
  }
  if (screen === 'paywall-ai' || screen === 'paywall-video') {
    return <Paywall reason={screen==='paywall-video'?'video':'ai'}
      onClose={goStudio}
      onUnlock={()=>{
        setIsLegendary(true);
        setScreen(screen==='paywall-video' ? 'magic-video' : 'ai-gallery');
      }}/>;
  }
  if (screen === 'post') {
    return <PostCreate fact={FACT} name={name} source={editorSource} kind={postKind}
      onClose={goFact}
      onMakeAnother={goStudio}
      onMerch={()=>{}}/>;
  }
  return null;
}

function makeArtboard({label, screen, name, defaultMode, isLegendary}) {
  const id = label.toLowerCase().replace(/\s+/g,'-');
  return (
    <DCArtboard key={id} id={id} label={label}
      width={FRAME_W+40} height={FRAME_H+60}>
      <div style={{padding:20,display:'flex',justifyContent:'center'}}>
        <PhoneFrame>
          <MiniFlow startScreen={screen} name={name}
            defaultMode={defaultMode} isLegendary={isLegendary}/>
        </PhoneFrame>
      </div>
    </DCArtboard>
  );
}

const DESK_W = 1280, DESK_H = 860;

function DesktopBezel({children}) {
  return (
    <div style={{width:DESK_W,height:DESK_H,background:'#000',
      borderRadius:14,overflow:'hidden',
      border:'1px solid #2a2a2a',
      boxShadow:'0 30px 60px -20px rgba(0,0,0,0.45)',
      position:'relative'}}>
      <div style={{height:32,background:'#161618',borderBottom:'1px solid #2a2a2a',
        display:'flex',alignItems:'center',padding:'0 14px',gap:8,position:'relative',zIndex:10}}>
        <div style={{width:11,height:11,borderRadius:6,background:'#ff5f57'}}/>
        <div style={{width:11,height:11,borderRadius:6,background:'#febc2e'}}/>
        <div style={{width:11,height:11,borderRadius:6,background:'#28c840'}}/>
        <div style={{flex:1,textAlign:'center',fontSize:11,color:'#888',fontFamily:"'Inter',sans-serif"}}>
          overhype.me
        </div>
      </div>
      <div style={{position:'absolute',top:32,left:0,right:0,bottom:0}}>
        {children}
      </div>
    </div>
  );
}

function makeDesktopArtboard({label, screen, name, defaultMode, isLegendary}) {
  const id = 'desktop-' + label.toLowerCase().replace(/\s+/g,'-');

  const handlePick = () => {}; // static artboards
  const Comp = (() => {
    if (screen === 'd-studio') return <DStudioEntry fact={FACT} name={name}
      defaultMode={defaultMode} isLegendary={isLegendary} onPickPath={handlePick}/>;
    if (screen === 'd-editor') return <DEditor fact={FACT} name={name}
      source={{k:'ai',vibe:'cosmic'}} onClose={()=>{}} onSave={()=>{}}/>;
    if (screen === 'd-ai') return <DAIGallery fact={FACT} name={name}
      generating={false} onGenerate={()=>{}} onPick={()=>{}} onClose={()=>{}}/>;
    if (screen === 'd-post') return <DPostCreate fact={FACT} name={name}
      source={{k:'ai',vibe:'cosmic'}} kind="image"
      onClose={()=>{}} onMakeAnother={()=>{}} onMerch={()=>{}}/>;
    return null;
  })();

  return (
    <DCArtboard key={id} id={id} label={label}
      width={DESK_W+40} height={DESK_H+40}>
      <div style={{padding:20}}>
        <DesktopBezel>{Comp}</DesktopBezel>
      </div>
    </DCArtboard>
  );
}

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAKS);
  const name = tweaks.name || 'Riley';

  return (
    <>
      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        @keyframes progress {
          0% { width: 0%; }
          100% { width: 100%; }
        }
      `}</style>

      <DesignCanvas>
        <DCSection id="flow" title="The redesigned flow"
          subtitle="Fact → Studio (entry hub) → path. Step through each artboard to feel the journey. Tweak 'AI-first' on/off in the panel to flip the recommended hero CTA.">
          {makeArtboard({label:'1. Fact detail', screen:'fact', name, defaultMode:tweaks.defaultMode, isLegendary:tweaks.isLegendary})}
          {makeArtboard({label:'2. Studio entry', screen:'studio', name, defaultMode:tweaks.defaultMode, isLegendary:tweaks.isLegendary})}
          {makeArtboard({label:'3a. AI gallery', screen:'ai-gallery', name, defaultMode:tweaks.defaultMode, isLegendary:true})}
          {makeArtboard({label:'3b. AI gallery (paywall)', screen:'paywall-ai', name, defaultMode:tweaks.defaultMode, isLegendary:false})}
          {makeArtboard({label:'4. Image editor', screen:'editor', name, defaultMode:tweaks.defaultMode, isLegendary:tweaks.isLegendary})}
          {makeArtboard({label:'5a. Magic video', screen:'magic-video', name, defaultMode:tweaks.defaultMode, isLegendary:true})}
          {makeArtboard({label:'5b. Manual video', screen:'manual-video', name, defaultMode:tweaks.defaultMode, isLegendary:true})}
          {makeArtboard({label:'6. Post-create', screen:'post', name, defaultMode:tweaks.defaultMode, isLegendary:tweaks.isLegendary})}
        </DCSection>

        <DCSection id="modes" title="Default mode comparison"
          subtitle="Same Studio screen, different defaultMode. AI-first promotes the AI image; Photo-first leads with Your photo. Both keep Magic Video as the secondary one-tap path.">
          {makeArtboard({label:'AI-first hero', screen:'studio', name, defaultMode:'ai', isLegendary:false})}
          {makeArtboard({label:'Photo-first hero', screen:'studio', name, defaultMode:'photo', isLegendary:false})}
        </DCSection>

        <DCSection id="desktop" title="Desktop"
          subtitle="Same flow at 1280×860. Sidebar nav swaps the bottom tabs; canvas-and-rail editor replaces the bottom sheet; AI library opens up to a generator panel + 3-column grid. Navigation parity with mobile, more breathing room.">
          {makeDesktopArtboard({label:'Desktop · Studio', screen:'d-studio', name, defaultMode:tweaks.defaultMode, isLegendary:tweaks.isLegendary})}
          {makeDesktopArtboard({label:'Desktop · AI gallery', screen:'d-ai', name, defaultMode:tweaks.defaultMode, isLegendary:true})}
          {makeDesktopArtboard({label:'Desktop · Editor', screen:'d-editor', name, defaultMode:tweaks.defaultMode, isLegendary:tweaks.isLegendary})}
          {makeDesktopArtboard({label:'Desktop · Post-create', screen:'d-post', name, defaultMode:tweaks.defaultMode, isLegendary:tweaks.isLegendary})}
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Meme builder tweaks">
        <TweakSection title="Identity">
          <TweakText label="Name" value={tweaks.name}
            onChange={v => setTweak('name', v)}/>
        </TweakSection>
        <TweakSection title="Default flow">
          <TweakRadio label="Studio leads with"
            options={[
              {value:'ai', label:'AI-first'},
              {value:'photo', label:'Photo-first'},
            ]}
            value={tweaks.defaultMode}
            onChange={v => setTweak('defaultMode', v)}/>
          <TweakToggle label="User is Legendary"
            value={tweaks.isLegendary}
            onChange={v => setTweak('isLegendary', v)}/>
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
