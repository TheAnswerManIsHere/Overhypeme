// Desktop versions of meme builder screens — 1280×860 layout

const { P: D_P, F: D_F, Hyped: D_Hy, FlameMark: D_FM, Wordmark: D_WM, PortraitBG: D_PG } = window.OvTokens;
const { I: D_I, Avatar: D_Av, Chip: D_Ch, PrimaryCTA: D_PC, SecondaryCTA: D_SC } = window.OvShell;
const { MemeCanvas: D_MC, RATIOS: D_RT, WORD_STYLES: D_WS } = window.OvStudio;
const { useState: D_uS, useEffect: D_uE } = React;

const DW = 1280, DH = 860;

// ─── Desktop chrome ──
const DesktopShell = ({children}) => (
  <div style={{position:'absolute',inset:0,background:D_P.bg,color:D_P.fg,
    fontFamily:D_F.body,overflow:'hidden'}}>
    {children}
  </div>
);

const DesktopNav = ({active='create'}) => {
  const items = [
    {k:'home',label:'Home', icon:'image'},
    {k:'create',label:'Create', icon:'sparkle'},
    {k:'library',label:'Library', icon:'shop'},
    {k:'hof',label:'Hall of Fame', icon:'crown'},
  ];
  return (
    <div style={{position:'absolute',top:0,left:0,bottom:0,width:220,
      background:D_P.bg2,borderRight:`1px solid ${D_P.hairline}`,
      padding:'24px 14px',display:'flex',flexDirection:'column',gap:6}}>
      <div style={{padding:'4px 12px 18px'}}>
        <D_WM size={15}/>
      </div>
      {items.map(it => (
        <div key={it.k} style={{padding:'10px 12px',borderRadius:10,
          background: active===it.k ? D_P.card : 'transparent',
          color: active===it.k ? D_P.fg : D_P.fg2,
          display:'flex',alignItems:'center',gap:10,cursor:'pointer',
          fontSize:13,fontWeight:600}}>
          <D_I k={it.icon} size={16}/>
          {it.label}
          {it.k==='create' && active!==it.k &&
            <span style={{marginLeft:'auto',width:6,height:6,borderRadius:3,background:D_P.primary}}/>}
        </div>
      ))}
      <div style={{flex:1}}/>
      <div style={{padding:'12px',borderRadius:12,background:D_P.card,
        border:`1px solid ${D_P.hairlineStrong}`}}>
        <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:11,
          letterSpacing:'0.16em',color:D_P.primary,textTransform:'uppercase',marginBottom:4}}>
          👑 Legendary
        </div>
        <div style={{fontSize:11,color:D_P.fg2,lineHeight:1.4,marginBottom:8}}>
          Unlimited AI generations
        </div>
        <button style={{width:'100%',padding:'8px',borderRadius:8,
          background:D_P.primary,color:'#fff',border:'none',cursor:'pointer',
          fontSize:11,fontWeight:700,letterSpacing:'0.1em',
          fontFamily:D_F.display,textTransform:'uppercase'}}>
          Upgrade
        </button>
      </div>
    </div>
  );
};

// ─── Desktop Studio entry ──
function DStudioEntry({fact, name, defaultMode, isLegendary, onPickPath}) {
  const aiFirst = defaultMode === 'ai';
  return (
    <DesktopShell>
      <DesktopNav active="create"/>
      <div style={{position:'absolute',top:0,left:220,right:0,bottom:0,overflowY:'auto'}}>
        {/* Header strip */}
        <div style={{padding:'24px 40px',borderBottom:`1px solid ${D_P.hairline}`,
          display:'flex',alignItems:'center',gap:16}}>
          <button style={{width:36,height:36,borderRadius:18,background:D_P.card,
            border:'none',color:D_P.fg,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <D_I k="back" size={18}/>
          </button>
          <div style={{flex:1}}>
            <div style={{fontSize:11,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
              fontFamily:D_F.display,textTransform:'uppercase',marginBottom:4}}>
              Make a meme · Step 1 of 2
            </div>
            <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:24,
              textTransform:'uppercase',letterSpacing:'-0.01em',lineHeight:1}}>
              {fact.replace(/\{N\}/g, name).split(name).map((p,i,a)=>
                i<a.length-1 ? <React.Fragment key={i}>{p}<D_Hy>{name}</D_Hy></React.Fragment>
                  : <React.Fragment key={i}>{p}</React.Fragment>)}
            </div>
          </div>
          <D_Av name={name} size={36}/>
        </div>

        <div style={{padding:'32px 40px'}}>
          {/* Two-column hero + magic */}
          <div style={{display:'grid',gridTemplateColumns:'1.6fr 1fr',gap:20,marginBottom:24}}>
            {/* Hero */}
            <div onClick={()=>onPickPath(aiFirst ? 'ai-image' : 'photo-image')} style={{
              borderRadius:20,overflow:'hidden',cursor:'pointer',position:'relative',
              background: aiFirst
                ? `linear-gradient(135deg, ${D_P.primary} 0%, #c0392b 100%)`
                : D_P.card,
              border: aiFirst ? 'none' : `1px solid ${D_P.hairlineStrong}`,
              boxShadow: aiFirst ? `0 16px 40px ${D_P.primaryGlow}` : 'none',
              display:'flex',alignItems:'stretch',
            }}>
              <div style={{flex:1,padding:'32px 32px',display:'flex',flexDirection:'column',justifyContent:'flex-end',
                color: aiFirst ? '#fff' : D_P.fg}}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                  {aiFirst && <D_I k="sparkle" size={14} stroke={2.2}/>}
                  <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:11,
                    letterSpacing:'0.18em',textTransform:'uppercase',
                    opacity: aiFirst ? 1 : 0.6}}>
                    {aiFirst ? '✨ Recommended · AI image' : 'Photo meme'}
                  </div>
                </div>
                <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:36,
                  textTransform:'uppercase',letterSpacing:'-0.015em',lineHeight:0.98,marginBottom:12,maxWidth:380}}>
                  {aiFirst
                    ? <>See <D_Hy>you</D_Hy> doing the impossible.</>
                    : <>Use your photo</>}
                </div>
                <div style={{fontSize:14, opacity: aiFirst ? 0.92 : 0.7,lineHeight:1.4,maxWidth:380,marginBottom:18}}>
                  {aiFirst
                    ? `AI dramatizes the fact — ${name} as the literal subject.`
                    : 'Drop your face on it. Words snap into place automatically.'}
                </div>
                <button style={{
                  alignSelf:'flex-start',padding:'12px 22px',borderRadius:12,
                  background: aiFirst ? '#fff' : D_P.primary,
                  color: aiFirst ? '#000' : '#fff',
                  border:'none',cursor:'pointer',
                  fontFamily:D_F.display,fontWeight:700,fontSize:12,
                  letterSpacing:'0.14em',textTransform:'uppercase',
                  display:'inline-flex',alignItems:'center',gap:8}}>
                  {aiFirst ? 'Generate AI image' : 'Upload photo'}
                  <D_I k="back" size={14} style={{transform:'rotate(180deg)'}}/>
                </button>
              </div>
              <div style={{width:280,padding:'24px 24px 24px 0',display:'flex',alignItems:'center',justifyContent:'center'}}>
                <D_MC fact={fact} name={name} ratio="1:1"
                  source={aiFirst ? {k:'ai',vibe:'cosmic'} : {k:'photo',tone:0}}
                  wordStyle="classic" wordPos="bottom" scale={0.78}/>
              </div>
            </div>

            {/* Magic video card */}
            <button onClick={()=>onPickPath(isLegendary ? 'magic-video' : 'paywall-video')}
              style={{padding:'28px',background:D_P.card,
              border:`1px solid ${D_P.hairlineStrong}`,borderRadius:20,
              cursor:'pointer',color:D_P.fg,textAlign:'left',
              display:'flex',flexDirection:'column',justifyContent:'space-between'}}>
              <div>
                <div style={{width:56,height:56,borderRadius:14,
                  background:`linear-gradient(135deg, ${D_P.primary}, #c0392b)`,
                  display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',marginBottom:18}}>
                  <D_I k="wand" size={26} stroke={2.2}/>
                </div>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                  <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:12,
                    textTransform:'uppercase',letterSpacing:'0.16em',color:D_P.fg}}>
                    Magic video
                  </div>
                  {!isLegendary && (
                    <div style={{padding:'2px 8px',borderRadius:6,background:D_P.primarySoft,
                      color:D_P.primary,fontSize:9,fontWeight:700,letterSpacing:'0.14em',
                      fontFamily:D_F.display}}>LEGENDARY</div>
                  )}
                </div>
                <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:22,
                  textTransform:'uppercase',letterSpacing:'-0.005em',lineHeight:1.05,marginBottom:8}}>
                  One tap, one video.
                </div>
                <div style={{fontSize:13,color:D_P.fg2,lineHeight:1.4}}>
                  AI scene → animated video of you. No decisions required.
                </div>
              </div>
              <div style={{display:'inline-flex',alignItems:'center',gap:6,
                color:D_P.primary,fontSize:12,fontWeight:600,marginTop:18}}>
                Conjure <D_I k="back" size={12} style={{transform:'rotate(180deg)'}}/>
              </div>
            </button>
          </div>

          {/* Other ways */}
          <div style={{fontSize:11,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
            fontFamily:D_F.display,textTransform:'uppercase',marginBottom:14}}>
            Other ways
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4, 1fr)',gap:12}}>
            {[
              {k:'photo',label:aiFirst?'Photo meme':'AI image',
                icon:aiFirst?'camera':'sparkle',
                sub:aiFirst?'Use camera roll':'Generate scene',
                locked:!aiFirst && !isLegendary,
                path:aiFirst?'photo-image':(isLegendary?'ai-gallery':'paywall-ai')},
              {k:'manual',label:'Manual video',icon:'video',sub:'Pick source · animate',
                locked:!isLegendary,path:isLegendary?'manual-video':'paywall-video'},
              {k:'stock',label:'Stock photo',icon:'image',sub:'Pre-made backgrounds',path:'stock-image'},
              {k:'color',label:'Color',icon:'image',sub:'Gradient or solid',path:'gradient-image'},
            ].map(s => (
              <button key={s.k} onClick={()=>onPickPath(s.path)} style={{
                padding:'18px',background:D_P.card,
                border:`1px solid ${D_P.hairlineStrong}`,borderRadius:14,
                cursor:'pointer',color:D_P.fg,textAlign:'left',
                display:'flex',flexDirection:'column',gap:12,position:'relative'}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                  <div style={{width:34,height:34,borderRadius:10,background:D_P.bg2,
                    display:'flex',alignItems:'center',justifyContent:'center',color:D_P.fg2}}>
                    <D_I k={s.icon} size={16}/>
                  </div>
                  {s.locked && <D_I k="lock" size={13} style={{color:D_P.amber}}/>}
                </div>
                <div>
                  <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:13,
                    textTransform:'uppercase',letterSpacing:'0.04em'}}>{s.label}</div>
                  <div style={{fontSize:11,color:D_P.muted,marginTop:3}}>{s.sub}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </DesktopShell>
  );
}

// ─── Desktop Editor — split layout: canvas center, controls right ──
function DEditor({fact, name, source, onClose, onSave}) {
  const [ratio, setRatio] = D_uS('1:1');
  const [wordStyle, setWordStyle] = D_uS('classic');
  const [wordPos, setWordPos] = D_uS('bottom');

  return (
    <DesktopShell>
      <DesktopNav active="create"/>
      {/* Top bar */}
      <div style={{position:'absolute',top:0,left:220,right:0,height:64,
        borderBottom:`1px solid ${D_P.hairline}`,background:D_P.bg,
        display:'flex',alignItems:'center',padding:'0 24px',gap:16,zIndex:5}}>
        <button onClick={onClose} style={{width:36,height:36,borderRadius:18,background:D_P.card,
          border:'none',color:D_P.fg,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
          <D_I k="back" size={18}/>
        </button>
        <div style={{flex:1,fontFamily:D_F.display,fontWeight:700,fontSize:14,
          letterSpacing:'0.14em',textTransform:'uppercase'}}>Editor</div>
        <button style={{padding:'10px 16px',borderRadius:10,background:'transparent',
          border:`1px solid ${D_P.hairlineStrong}`,color:D_P.fg,cursor:'pointer',
          fontSize:12,fontWeight:600,display:'inline-flex',alignItems:'center',gap:6}}>
          <D_I k="refresh" size={14}/> Swap source
        </button>
        <button onClick={onSave} style={{padding:'10px 22px',borderRadius:10,
          background:D_P.primary,color:'#fff',border:'none',cursor:'pointer',
          fontFamily:D_F.display,fontWeight:700,fontSize:11,letterSpacing:'0.16em',
          textTransform:'uppercase'}}>Save meme</button>
      </div>

      {/* Canvas area */}
      <div style={{position:'absolute',top:64,left:220,right:340,bottom:0,
        background:'#000',display:'flex',alignItems:'center',justifyContent:'center',padding:40}}>
        <div style={{transform:'scale(1.4)',transformOrigin:'center'}}>
          <D_MC fact={fact} name={name} ratio={ratio} source={source}
            wordStyle={wordStyle} wordPos={wordPos}
            scale={ratio==='9:16' ? 0.7 : (ratio==='16:9' ? 1 : 0.85)}/>
        </div>
      </div>

      {/* Right rail */}
      <div style={{position:'absolute',top:64,right:0,bottom:0,width:340,
        background:D_P.bg2,borderLeft:`1px solid ${D_P.hairline}`,
        overflowY:'auto',padding:'20px 20px 30px'}}>

        {/* Aspect ratios */}
        <div style={{marginBottom:20}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
            fontFamily:D_F.display,textTransform:'uppercase',marginBottom:10}}>Shape</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:6}}>
            {D_RT.map(r => (
              <button key={r.k} onClick={()=>setRatio(r.k)} style={{
                padding:'10px 6px',borderRadius:10,
                background: ratio===r.k ? D_P.fg : D_P.card,
                color: ratio===r.k ? D_P.bg : D_P.fg,
                border: ratio===r.k ? 'none' : `1px solid ${D_P.hairlineStrong}`,
                cursor:'pointer',fontSize:11,fontWeight:600,
                display:'flex',flexDirection:'column',alignItems:'center',gap:4,
              }}>
                <span style={{display:'inline-block',
                  width: r.w >= r.h ? 18 : 18*r.w/r.h,
                  height: r.h >= r.w ? 14 : 14*r.h/r.w,
                  border:'1.5px solid currentColor',borderRadius:2}}/>
                {r.k}
              </button>
            ))}
          </div>
        </div>

        {/* Style */}
        <div style={{marginBottom:20}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
            fontFamily:D_F.display,textTransform:'uppercase',marginBottom:10}}>Style</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:6}}>
            {D_WS.map(w => (
              <button key={w.k} onClick={()=>setWordStyle(w.k)} style={{
                padding:'12px',borderRadius:10,
                background: wordStyle===w.k ? D_P.fg : D_P.card,
                color: wordStyle===w.k ? D_P.bg : D_P.fg,
                border: wordStyle===w.k ? 'none' : `1px solid ${D_P.hairlineStrong}`,
                cursor:'pointer',fontFamily:D_F.display,fontWeight:700,
                fontSize:12,textTransform:'uppercase',letterSpacing:'0.06em'}}>
                {w.label}
              </button>
            ))}
          </div>
        </div>

        {/* Position */}
        <div style={{marginBottom:20}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
            fontFamily:D_F.display,textTransform:'uppercase',marginBottom:10}}>Position</div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
            {[{k:'top',l:'Top'},{k:'bottom',l:'Bottom'}].map(p => (
              <button key={p.k} onClick={()=>setWordPos(p.k)} style={{
                padding:'12px',borderRadius:10,
                background: wordPos===p.k ? D_P.fg : D_P.card,
                color: wordPos===p.k ? D_P.bg : D_P.fg,
                border: wordPos===p.k ? 'none' : `1px solid ${D_P.hairlineStrong}`,
                cursor:'pointer',fontSize:12,fontWeight:600}}>
                {p.l}
              </button>
            ))}
          </div>
          <div style={{fontSize:11,color:D_P.muted,marginTop:8,fontStyle:'italic'}}>
            Tip: drag the words on canvas for free placement
          </div>
        </div>

        {/* Advanced collapsed */}
        <div style={{marginBottom:14}}>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
            fontFamily:D_F.display,textTransform:'uppercase',marginBottom:10}}>Advanced</div>
          {[
            {l:'Font', s:'Oswald'},{l:'Size', s:'Auto · 28pt'},
            {l:'Color', s:'White'},{l:'Stroke', s:'None'},{l:'Shadow', s:'Soft'},
          ].map(it => (
            <div key={it.l} style={{padding:'10px 12px',borderRadius:8,background:D_P.card,
              marginBottom:4,display:'flex',alignItems:'center',cursor:'pointer'}}>
              <div style={{flex:1,fontSize:12,fontWeight:600}}>{it.l}</div>
              <div style={{fontSize:11,color:D_P.muted,marginRight:8}}>{it.s}</div>
              <D_I k="back" size={12} style={{transform:'rotate(180deg)',color:D_P.muted}}/>
            </div>
          ))}
        </div>
      </div>
    </DesktopShell>
  );
}

// ─── Desktop AI Gallery ──
const D_AI_IMAGES = [
  {id:1,vibe:'cosmic',prompt:'Pushing the universe',new:true},
  {id:2,vibe:'galactic',prompt:'Slap heard worldwide'},
  {id:3,vibe:'mythic',prompt:'Time freeze stance'},
  {id:4,vibe:'cyber',prompt:'Wi-Fi origin moment'},
  {id:5,vibe:'gold',prompt:'Cover-confessing'},
  {id:6,vibe:'storm',prompt:'Noir frame'},
];

function DAIGallery({fact, name, onClose, onPick, generating, onGenerate}) {
  const [vibe, setVibe] = D_uS('cosmic');
  const vibes = [
    {k:'cosmic',label:'Cosmic'},{k:'galactic',label:'Epic'},
    {k:'mythic',label:'Mythic'},{k:'cyber',label:'Cyber'},
    {k:'gold',label:'Royal'},{k:'storm',label:'Noir'},
  ];

  return (
    <DesktopShell>
      <DesktopNav active="create"/>
      <div style={{position:'absolute',top:0,left:220,right:0,bottom:0,overflowY:'auto'}}>
        <div style={{padding:'24px 40px',borderBottom:`1px solid ${D_P.hairline}`,
          display:'flex',alignItems:'center',gap:16}}>
          <button onClick={onClose} style={{width:36,height:36,borderRadius:18,background:D_P.card,
            border:'none',color:D_P.fg,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <D_I k="back" size={18}/>
          </button>
          <div style={{flex:1}}>
            <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:24,
              textTransform:'uppercase',letterSpacing:'-0.01em',lineHeight:1}}>
              AI image
            </div>
            <div style={{fontSize:12,color:D_P.muted,marginTop:4}}>
              About {name} · {fact.replace(/\{N\}/g, name).slice(0,60)}…
            </div>
          </div>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'320px 1fr',gap:0,minHeight:'calc(100% - 80px)'}}>
          {/* Generator panel */}
          <div style={{padding:'24px',borderRight:`1px solid ${D_P.hairline}`}}>
            <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
              fontFamily:D_F.display,textTransform:'uppercase',marginBottom:10}}>
              Generate new
            </div>
            <div style={{fontSize:11,fontWeight:700,letterSpacing:'0.14em',color:D_P.fg2,
              fontFamily:D_F.display,textTransform:'uppercase',marginBottom:8}}>Style</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6,marginBottom:16}}>
              {vibes.map(v => (
                <button key={v.k} onClick={()=>setVibe(v.k)} style={{
                  padding:'10px',borderRadius:8,
                  background: vibe===v.k ? D_P.fg : D_P.card,
                  color: vibe===v.k ? D_P.bg : D_P.fg,
                  border: vibe===v.k ? 'none' : `1px solid ${D_P.hairlineStrong}`,
                  cursor:'pointer',fontSize:11,fontWeight:600}}>
                  {v.label}
                </button>
              ))}
            </div>

            <button onClick={onGenerate} disabled={generating} style={{
              width:'100%',padding:'14px',borderRadius:10,
              background:generating?D_P.card:D_P.primary,color:'#fff',border:'none',cursor:'pointer',
              fontFamily:D_F.display,fontWeight:700,fontSize:11,letterSpacing:'0.14em',
              textTransform:'uppercase',display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
              <D_I k="sparkle" size={14}/>
              {generating ? 'Generating…' : `Generate ${vibe}`}
            </button>
            <div style={{fontSize:11,color:D_P.muted,marginTop:8,textAlign:'center'}}>
              ~15 seconds · 1 of 30 this month
            </div>
          </div>

          {/* Library grid */}
          <div style={{padding:'24px'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14}}>
              <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
                fontFamily:D_F.display,textTransform:'uppercase'}}>
                Your library · {D_AI_IMAGES.length}
              </div>
              <div style={{fontSize:11,color:D_P.muted}}>Click any image to open in editor</div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3, 1fr)',gap:14}}>
              {generating && (
                <div style={{aspectRatio:'1/1.2',borderRadius:14,overflow:'hidden',
                  position:'relative',background:D_P.card,
                  display:'flex',alignItems:'center',justifyContent:'center'}}>
                  <div style={{position:'absolute',inset:0,
                    background:`linear-gradient(90deg, transparent, ${D_P.primarySoft}, transparent)`,
                    animation:'shimmer 1.5s infinite'}}/>
                  <D_I k="sparkle" size={28} style={{color:D_P.primary,zIndex:1}}/>
                </div>
              )}
              {D_AI_IMAGES.map(img => (
                <button key={img.id} onClick={()=>onPick(img)} style={{
                  padding:0,border:'none',background:'transparent',cursor:'pointer',
                  position:'relative',borderRadius:14,overflow:'hidden',aspectRatio:'1/1.2'}}>
                  <D_PG vibe={img.vibe}/>
                  {img.new && (
                    <div style={{position:'absolute',top:10,left:10,padding:'3px 8px',borderRadius:999,
                      background:D_P.primary,color:'#fff',fontSize:9,fontWeight:700,
                      letterSpacing:'0.12em',fontFamily:D_F.display,zIndex:2}}>NEW</div>
                  )}
                  <div style={{position:'absolute',inset:0,
                    background:'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.75))'}}/>
                  <div style={{position:'absolute',left:12,right:12,bottom:12,zIndex:2,textAlign:'left'}}>
                    <div style={{fontSize:10,fontFamily:D_F.display,fontWeight:700,
                      color:D_P.primary,letterSpacing:'0.1em',textTransform:'uppercase'}}>{img.vibe}</div>
                    <div style={{fontSize:11,color:'rgba(255,255,255,0.85)',marginTop:2}}>{img.prompt}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DesktopShell>
  );
}

// ─── Desktop Post-create ──
function DPostCreate({fact, name, source, kind='image', onClose, onMakeAnother, onMerch}) {
  return (
    <DesktopShell>
      <DesktopNav active="create"/>
      <div style={{position:'absolute',top:0,left:220,right:0,bottom:0,overflowY:'auto'}}>
        <div style={{padding:'24px 40px',borderBottom:`1px solid ${D_P.hairline}`,
          display:'flex',alignItems:'center',gap:16}}>
          <button onClick={onClose} style={{width:36,height:36,borderRadius:18,background:D_P.card,
            border:'none',color:D_P.fg,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <D_I k="back" size={18}/>
          </button>
          <div style={{flex:1}}>
            <div style={{display:'inline-flex',alignItems:'center',gap:6,padding:'4px 10px',borderRadius:999,
              background:`rgba(52,199,89,0.15)`,color:D_P.success,fontSize:11,fontWeight:700,
              letterSpacing:'0.14em',fontFamily:D_F.display,textTransform:'uppercase',marginBottom:6}}>
              <D_I k="check" size={12} stroke={2.4}/> {kind==='image'?'Image':'Video'} saved
            </div>
            <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:24,
              textTransform:'uppercase',letterSpacing:'-0.01em',lineHeight:1}}>
              Now share <D_Hy>{name}</D_Hy>'s legend.
            </div>
          </div>
        </div>

        <div style={{padding:'32px 40px',display:'grid',gridTemplateColumns:'420px 1fr',gap:32}}>
          {/* Preview */}
          <div>
            <div style={{position:'relative'}}>
              <D_MC fact={fact} name={name} ratio="1:1" source={source}
                wordStyle="classic" wordPos="bottom" scale={1.15}/>
              {kind === 'video' && (
                <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',pointerEvents:'none'}}>
                  <div style={{width:64,height:64,borderRadius:32,background:'rgba(0,0,0,0.6)',
                    backdropFilter:'blur(8px)',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff'}}>
                    <D_I k="play" size={26}/>
                  </div>
                </div>
              )}
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginTop:14}}>
              <button style={{padding:'12px',borderRadius:10,background:D_P.card,
                border:`1px solid ${D_P.hairlineStrong}`,color:D_P.fg,cursor:'pointer',
                fontSize:12,fontWeight:600,display:'inline-flex',alignItems:'center',justifyContent:'center',gap:6}}>
                <D_I k="download" size={14}/> Download
              </button>
              <button onClick={onMakeAnother} style={{padding:'12px',borderRadius:10,background:'transparent',
                border:`1px dashed ${D_P.hairlineStrong}`,color:D_P.fg,cursor:'pointer',
                fontSize:12,fontWeight:600,display:'inline-flex',alignItems:'center',justifyContent:'center',gap:6}}>
                <D_I k="plus" size={14}/> Make another
              </button>
            </div>
          </div>

          {/* Right column */}
          <div>
            <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
              fontFamily:D_F.display,textTransform:'uppercase',marginBottom:12}}>
              Share to socials
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(2, 1fr)',gap:10,marginBottom:24}}>
              {[
                {k:'ig',label:'Instagram',c:'#E1306C',sub:'Story · Auto-formatted 9:16'},
                {k:'tt',label:'TikTok',c:'#000',sub:kind==='video'?'Video · Direct upload':'Post · Carousel'},
                {k:'x',label:'X (Twitter)',c:'#000',sub:'Post with caption'},
                {k:'wa',label:'WhatsApp',c:'#25D366',sub:'Status · 9:16 ready'},
              ].map(s => (
                <button key={s.k} style={{padding:'14px',background:D_P.card,
                  border:`1px solid ${D_P.hairlineStrong}`,borderRadius:12,cursor:'pointer',color:D_P.fg,
                  display:'flex',alignItems:'center',gap:12,textAlign:'left'}}>
                  <div style={{width:40,height:40,borderRadius:10,background:s.c,
                    display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',
                    fontFamily:D_F.display,fontWeight:700,fontSize:16,flexShrink:0}}>{s.label[0]}</div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:13,fontWeight:600,fontFamily:D_F.body}}>{s.label}</div>
                    <div style={{fontSize:11,color:D_P.muted,marginTop:2,
                      whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{s.sub}</div>
                  </div>
                </button>
              ))}
            </div>

            {kind === 'image' && (
              <>
                <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',color:D_P.muted,
                  fontFamily:D_F.display,textTransform:'uppercase',marginBottom:12}}>
                  Wear it
                </div>
                <button onClick={onMerch} style={{
                  width:'100%',padding:'18px',background:D_P.card,
                  border:`1px solid ${D_P.hairlineStrong}`,borderRadius:14,cursor:'pointer',color:D_P.fg,
                  display:'flex',alignItems:'center',gap:14,textAlign:'left'}}>
                  <div style={{display:'flex',gap:6,flexShrink:0}}>
                    {['#000','#fff',D_P.primary].map((c,i) => (
                      <div key={i} style={{width:50,height:60,borderRadius:8,background:c,
                        display:'flex',alignItems:'center',justifyContent:'center',
                        border: c==='#fff' ? `1px solid ${D_P.hairlineStrong}` : 'none'}}>
                        <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:6,
                          color: c==='#fff'?'#000':'#fff', textAlign:'center', lineHeight:1,
                          textTransform:'uppercase'}}>
                          {name.toUpperCase()}<br/>WAS<br/>HERE
                        </div>
                      </div>
                    ))}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontFamily:D_F.display,fontWeight:700,fontSize:15,
                      textTransform:'uppercase',letterSpacing:'0.04em'}}>Turn into merch</div>
                    <div style={{fontSize:12,color:D_P.fg2,marginTop:3}}>
                      Tee · Hoodie · Sticker · Tote · From $22
                    </div>
                  </div>
                  <D_I k="back" size={16} style={{transform:'rotate(180deg)',color:D_P.muted}}/>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </DesktopShell>
  );
}

window.OvDesktopMeme = { DStudioEntry, DEditor, DAIGallery, DPostCreate, DesktopShell, DesktopNav };
