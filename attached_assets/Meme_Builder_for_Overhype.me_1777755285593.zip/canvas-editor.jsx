// Canvas editor — image meme editing with smart defaults
// Power tools live behind a "Tweak" sheet, not on the main canvas.

const { P: Pc, F: Fc, Hyped: Hyc } = window.OvTokens;
const { I: Icc, Chip: Chc, Shell: Shc, BottomSheet: BSc, PrimaryCTA: PCc, HeaderBar: HBc, Avatar: Avc } = window.OvShell;
const { MemeCanvas: MCc, RATIOS: Rc, BG_SOURCES: BSc2, WORD_STYLES: WSc } = window.OvStudio;
const { useState: uSc, useRef: uRc } = React;

// The canvas editor screen
function CanvasEditor({fact, name, source, onClose, onSave, onChangeSource}) {
  const [ratio, setRatio] = uSc('1:1');
  const [wordStyle, setWordStyle] = uSc('classic');
  const [wordPos, setWordPos] = uSc('bottom');
  const [tweakOpen, setTweakOpen] = uSc(false);
  const [tweakTab, setTweakTab] = uSc('text');

  const sourceLabel = {
    photo: 'Your photo', ai: 'AI image', stock: 'Stock photo', gradient: 'Color',
  }[source.k] || 'Photo';

  return (
    <Shc>
      <HBc onBack={onClose} title="Edit meme" right={
        <button onClick={()=>onSave({ratio, wordStyle, wordPos, source})}
          style={{padding:'8px 16px',background:Pc.primary,border:'none',borderRadius:999,
            color:'#fff',fontFamily:Fc.display,fontWeight:700,fontSize:11,
            letterSpacing:'0.14em',textTransform:'uppercase',cursor:'pointer'}}>
          Save
        </button>
      }/>

      {/* Canvas stage */}
      <div style={{position:'absolute',top:98,left:0,right:0,bottom:200,
        display:'flex',alignItems:'center',justifyContent:'center',padding:'12px 16px'}}>
        <MCc fact={fact} name={name} ratio={ratio} source={source}
          wordStyle={wordStyle} wordPos={wordPos} scale={0.85}/>
      </div>

      {/* Word position drag handles indicator */}
      <div style={{position:'absolute',bottom:200,left:0,right:0,
        textAlign:'center',fontSize:11,color:Pc.muted,fontFamily:Fc.body,
        pointerEvents:'none',marginBottom:6}}>
        Drag the words anywhere · Tap for options
      </div>

      {/* Bottom toolbar — fixed primary controls (the "ratio + source" we always want) */}
      <div style={{position:'absolute',left:0,right:0,bottom:24,padding:'0 12px'}}>
        {/* Source switcher row */}
        <div style={{padding:'10px 4px 8px',display:'flex',gap:8,overflowX:'auto'}}>
          {[
            {k:'photo', label:'Your photo', icon:'camera'},
            {k:'ai', label:'AI image', icon:'sparkle'},
            {k:'stock', label:'Stock', icon:'image'},
            {k:'gradient', label:'Color', icon:'image'},
          ].map(s=>(
            <button key={s.k} onClick={()=>onChangeSource(s.k)} style={{
              padding:'8px 12px',borderRadius:12,
              background: source.k===s.k ? Pc.primarySoft : Pc.card,
              border: source.k===s.k ? `1px solid ${Pc.primary}` : `1px solid ${Pc.hairlineStrong}`,
              color: source.k===s.k ? Pc.primary : Pc.fg2,
              fontFamily:Fc.body,fontSize:12,fontWeight:600,
              display:'flex',alignItems:'center',gap:6,whiteSpace:'nowrap',cursor:'pointer',
              flexShrink:0,
            }}>
              <Icc k={s.icon} size={14} stroke={2}/>
              {s.label}
            </button>
          ))}
        </div>

        {/* Inline aspect ratio strip — visual not text */}
        <div style={{display:'flex',gap:8,padding:'6px 4px 12px',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{display:'flex',gap:6,flex:1}}>
            {Rc.map(r=>{
              const active = ratio===r.k;
              const w = 22, h = 22 * (r.h/r.w);
              return (
                <button key={r.k} onClick={()=>setRatio(r.k)} style={{
                  flex:1,padding:'8px 0 6px',background: active ? Pc.cardHi : 'transparent',
                  border: active ? `1px solid ${Pc.fg}` : `1px solid ${Pc.hairlineStrong}`,
                  borderRadius:10,cursor:'pointer',color: active?Pc.fg:Pc.muted,
                  display:'flex',flexDirection:'column',alignItems:'center',gap:4,
                }}>
                  <div style={{width:w,height: Math.min(h,28),
                    border:`1.5px solid currentColor`,borderRadius:2}}/>
                  <div style={{fontSize:9,fontWeight:700,fontFamily:Fc.body,letterSpacing:'0.04em'}}>
                    {r.k}
                  </div>
                </button>
              );
            })}
          </div>
          <button onClick={()=>{setTweakOpen(true);setTweakTab('text');}} style={{
            padding:'10px 14px',background:Pc.card,
            border:`1px solid ${Pc.hairlineStrong}`,borderRadius:12,color:Pc.fg,
            fontFamily:Fc.body,fontSize:12,fontWeight:600,
            display:'flex',alignItems:'center',gap:6,cursor:'pointer'}}>
            <Icc k="type" size={14}/> Tweak
          </button>
        </div>
      </div>

      {/* Tweak sheet — power user controls */}
      {tweakOpen && (
        <BSc onClose={()=>setTweakOpen(false)} height={460}>
          <div style={{padding:'4px 16px 18px'}}>
            <div style={{display:'flex',gap:6,padding:'8px 0 14px'}}>
              {['text','position','effects'].map(t=>(
                <button key={t} onClick={()=>setTweakTab(t)} style={{
                  padding:'6px 12px',borderRadius:999,
                  background: tweakTab===t ? Pc.fg : 'transparent',
                  color: tweakTab===t ? Pc.bg : Pc.fg2,
                  border: tweakTab===t ? 'none' : `1px solid ${Pc.hairlineStrong}`,
                  fontFamily:Fc.body,fontSize:12,fontWeight:600,
                  textTransform:'capitalize',cursor:'pointer'}}>
                  {t}
                </button>
              ))}
            </div>

            {tweakTab==='text' && (
              <div>
                <Label>Style</Label>
                <div style={{display:'grid',gridTemplateColumns:'repeat(2, 1fr)',gap:8,marginBottom:18}}>
                  {WSc.map(w=>{
                    const active = wordStyle===w.k;
                    return (
                      <button key={w.k} onClick={()=>setWordStyle(w.k)} style={{
                        padding:'14px 12px',background: active ? Pc.cardHi : Pc.card,
                        border: active ? `1px solid ${Pc.primary}` : `1px solid ${Pc.hairlineStrong}`,
                        borderRadius:12,cursor:'pointer',
                        display:'flex',flexDirection:'column',alignItems:'flex-start',gap:6,
                      }}>
                        <div style={{fontSize:11,color:Pc.muted,fontFamily:Fc.body,fontWeight:600,
                          letterSpacing:'0.08em',textTransform:'uppercase'}}>{w.label}</div>
                        <div style={{
                          fontFamily:w.font,fontWeight:700,fontSize:18,
                          color:w.color,
                          textShadow:w.shadow,
                          WebkitTextStroke: w.stroke==='none'?'0':w.stroke,
                          background:w.bg !== 'none' ? w.bg : 'transparent',
                          padding:w.bg !== 'none' ? '3px 6px' : 0,
                          textTransform:'uppercase',letterSpacing:'-0.01em',
                        }}>Aa Bb</div>
                      </button>
                    );
                  })}
                </div>
                <Label>Color accent</Label>
                <div style={{display:'flex',gap:8}}>
                  {[Pc.primary,'#FFD700','#FF3B7B','#34C759','#7B68EE','#fff'].map(c=>(
                    <div key={c} style={{width:32,height:32,borderRadius:16,background:c,
                      border: c===Pc.primary ? `2px solid ${Pc.fg}` : `1px solid ${Pc.hairlineStrong}`,
                      cursor:'pointer'}}/>
                  ))}
                </div>
              </div>
            )}

            {tweakTab==='position' && (
              <div>
                <Label>Words sit at</Label>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8,marginBottom:18}}>
                  {[
                    {k:'top',label:'Top'},
                    {k:'bottom',label:'Bottom'},
                    {k:'split',label:'Split'},
                  ].map(p=>{
                    const active = wordPos===p.k;
                    const lineTop = p.k==='top'||p.k==='split';
                    const lineBot = p.k==='bottom'||p.k==='split';
                    return (
                      <button key={p.k} onClick={()=>setWordPos(p.k)} style={{
                        padding:'12px 10px',background: active ? Pc.cardHi : Pc.card,
                        border: active ? `1px solid ${Pc.primary}` : `1px solid ${Pc.hairlineStrong}`,
                        borderRadius:12,cursor:'pointer',
                        display:'flex',flexDirection:'column',alignItems:'center',gap:6,
                      }}>
                        <div style={{width:60,height:42,borderRadius:6,background:Pc.bg,
                          position:'relative',border:`1px solid ${Pc.hairline}`}}>
                          {lineTop && <div style={{position:'absolute',top:5,left:5,right:5,height:3,
                            background:Pc.fg,borderRadius:1.5}}/>}
                          {lineBot && <div style={{position:'absolute',bottom:5,left:5,right:5,height:3,
                            background:Pc.fg,borderRadius:1.5}}/>}
                        </div>
                        <div style={{fontSize:11,fontWeight:600,fontFamily:Fc.body}}>{p.label}</div>
                      </button>
                    );
                  })}
                </div>
                <div style={{padding:'12px 14px',background:Pc.card,borderRadius:12,
                  border:`1px solid ${Pc.hairlineStrong}`,
                  display:'flex',alignItems:'center',gap:10,fontSize:12,color:Pc.fg2,
                  fontFamily:Fc.body}}>
                  <Icc k="move" size={16}/>
                  Drag the words on the canvas for fine control.
                </div>
              </div>
            )}

            {tweakTab==='effects' && (
              <div>
                <Label>Background fade</Label>
                <div style={{display:'flex',gap:8,marginBottom:18}}>
                  {['None','Light','Strong'].map(f=>(
                    <button key={f} style={{
                      flex:1,padding:'12px 8px',background: f==='Light' ? Pc.cardHi : Pc.card,
                      border: f==='Light' ? `1px solid ${Pc.primary}` : `1px solid ${Pc.hairlineStrong}`,
                      borderRadius:12,cursor:'pointer',color:Pc.fg,
                      fontFamily:Fc.body,fontSize:12,fontWeight:600}}>{f}</button>
                  ))}
                </div>
                <Label>Filter</Label>
                <div style={{display:'flex',gap:8,overflowX:'auto'}}>
                  {['None','Punch','Cool','Warm','B&W','Gritty'].map((f,i)=>(
                    <button key={f} style={{
                      padding:'8px 14px',borderRadius:999,
                      background: i===0 ? Pc.fg : 'transparent',
                      color: i===0 ? Pc.bg : Pc.fg,
                      border: i===0 ? 'none' : `1px solid ${Pc.hairlineStrong}`,
                      fontFamily:Fc.body,fontSize:12,fontWeight:600,
                      whiteSpace:'nowrap',cursor:'pointer',flexShrink:0}}>{f}</button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </BSc>
      )}
    </Shc>
  );
}

const Label = ({children}) => (
  <div style={{fontSize:10,fontWeight:700,letterSpacing:'0.18em',
    color:Pc.muted,fontFamily:Fc.display,textTransform:'uppercase',marginBottom:10}}>
    {children}
  </div>
);

window.OvCanvas = { CanvasEditor, Label };
