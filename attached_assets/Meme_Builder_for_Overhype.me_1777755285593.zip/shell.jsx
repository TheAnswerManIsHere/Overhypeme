// Overhype.me Meme Builder — shell components

const { P, F, FACE_GRADS, Hyped, FlameMark, Wordmark, PortraitBG } = window.OvTokens;
const { useState, useEffect, useRef } = React;

// ─── Status / chrome ──────────────────────────────────────────
const StatusBar = ({dark=true}) => (
  <div style={{position:'absolute',top:0,left:0,right:0,height:44,display:'flex',
    alignItems:'center',justifyContent:'space-between',padding:'0 28px',
    color: dark ? '#fff' : '#000',fontSize:15,fontWeight:600,zIndex:100,pointerEvents:'none',
    fontFamily: F.body}}>
    <span style={{letterSpacing:'-0.02em'}}>9:41</span>
    <span style={{display:'flex',gap:6,alignItems:'center'}}>
      <svg width="18" height="11" viewBox="0 0 18 11"><path d="M1 8h2v3H1zM5 6h2v5H5zM9 4h2v7H9zM13 1h2v10h-2z" fill="currentColor"/></svg>
      <svg width="16" height="11" viewBox="0 0 16 11" fill="none"><path d="M14 .5 9 6.5l-3-3-5.5 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>
      <svg width="24" height="11" viewBox="0 0 24 11" fill="none"><rect x=".5" y=".5" width="20" height="10" rx="2.5" stroke="currentColor" opacity=".5"/><rect x="2" y="2" width="17" height="7" rx="1" fill="currentColor"/></svg>
    </span>
  </div>
);

const HomeIndicator = ({dark=true}) => (
  <div style={{position:'absolute',bottom:8,left:'50%',transform:'translateX(-50%)',
    width:134,height:5,borderRadius:3,
    background: dark ? 'rgba(255,255,255,0.45)' : 'rgba(0,0,0,0.45)',
    zIndex:100,pointerEvents:'none'}}/>
);

const Avatar = ({name='R',size=32,ring=false}) => (
  <div style={{
    width:size,height:size,borderRadius:'50%',
    background: ring ? `conic-gradient(${P.primary},#FF8C42,${P.primary})` : 'transparent',
    padding: ring ? 2 : 0,boxSizing:'border-box',flexShrink:0,
    display:'flex',alignItems:'center',justifyContent:'center'}}>
    <div style={{width:'100%',height:'100%',borderRadius:'50%',
      background:`linear-gradient(135deg,#FF6500,#c0392b)`,
      display:'flex',alignItems:'center',justifyContent:'center',
      color:'#fff',fontWeight:700,fontSize:size*0.42,fontFamily:F.display,
      border: ring ? `2px solid ${P.bg}` : 'none'}}>
      {(name[0]||'?').toUpperCase()}
    </div>
  </div>
);

// ─── Icon set ──
const Icon = {
  back: <path d="M15 18l-6-6 6-6"/>,
  close: <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>,
  share: <><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></>,
  download: <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></>,
  sparkle: <><path d="M12 2l2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/><path d="M19 14l1 2.5 2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z" strokeWidth="1.5"/></>,
  camera: <><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></>,
  image: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/></>,
  video: <><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></>,
  lock: <><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></>,
  check: <polyline points="20 6 9 17 4 12"/>,
  type: <><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></>,
  move: <><polyline points="5 9 2 12 5 15"/><polyline points="9 5 12 2 15 5"/><polyline points="15 19 12 22 9 19"/><polyline points="19 9 22 12 19 15"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="22"/></>,
  shop: <><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></>,
  more: <><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></>,
  refresh: <><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></>,
  play: <polygon points="5 3 19 12 5 21 5 3"/>,
  plus: <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
  crown: <path d="M2 18h20l-2-9-5 5-3-7-3 7-5-5z"/>,
  wand: <><path d="M9 17 5 13"/><path d="M9 17 17 9"/><path d="M14 12l-2 2"/><path d="M3 21l4-4"/><circle cx="14" cy="6" r="0.5" fill="currentColor"/><circle cx="20" cy="3" r="0.5" fill="currentColor"/><circle cx="20" cy="14" r="0.5" fill="currentColor"/></>,
};

const I = ({k,size=20,stroke=1.8,style}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={style}>{Icon[k]}</svg>
);

// ─── Pill / chip ──
const Chip = ({children, active=false, onClick, primary=false, locked=false, style}) => (
  <button onClick={onClick} style={{
    display:'inline-flex',alignItems:'center',gap:6,
    padding:'8px 14px',borderRadius:999,
    background: active ? P.fg : (primary ? P.primary : 'transparent'),
    color: active ? P.bg : (primary ? '#fff' : P.fg),
    border: active || primary ? 'none' : `1px solid ${P.hairlineStrong}`,
    fontFamily:F.body,fontSize:13,fontWeight:600,
    cursor:'pointer',whiteSpace:'nowrap',
    ...style,
  }}>
    {locked && <I k="lock" size={11} stroke={2.2}/>}
    {children}
  </button>
);

// ─── Header bar ──
const HeaderBar = ({onBack, title, right}) => (
  <div style={{position:'absolute',top:44,left:0,right:0,height:54,
    display:'flex',alignItems:'center',padding:'0 8px',
    background:`linear-gradient(180deg, ${P.bg} 0%, ${P.bg} 80%, transparent 100%)`,
    zIndex:5}}>
    <button onClick={onBack} style={{width:44,height:44,borderRadius:22,border:'none',background:'transparent',
      color:P.fg,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <I k="back" size={22}/>
    </button>
    <div style={{flex:1,textAlign:'center',fontFamily:F.display,fontWeight:700,
      fontSize:14,letterSpacing:'0.1em',textTransform:'uppercase',color:P.fg}}>
      {title}
    </div>
    <div style={{minWidth:44,display:'flex',justifyContent:'flex-end',paddingRight:8}}>
      {right}
    </div>
  </div>
);

// ─── Phone shell ──
const Shell = ({children, bg=P.bg}) => (
  <div style={{position:'absolute',inset:0,background:bg,color:P.fg,overflow:'hidden',fontFamily:F.body}}>
    <StatusBar/>
    <HomeIndicator/>
    {children}
  </div>
);

// ─── Bottom sheet ──
const BottomSheet = ({children, height='auto', dim=true, onClose, style}) => (
  <>
    {dim && <div onClick={onClose} style={{position:'absolute',inset:0,background:'rgba(0,0,0,0.55)',zIndex:10}}/>}
    <div style={{position:'absolute',left:0,right:0,bottom:0,zIndex:20,
      background:P.bg2,borderTopLeftRadius:24,borderTopRightRadius:24,
      padding:'10px 0 0',height,maxHeight:'92%',overflowY:'auto',
      boxShadow:'0 -20px 40px rgba(0,0,0,0.5)',
      ...style}}>
      <div style={{width:36,height:4,borderRadius:2,background:P.hairlineStrong,
        margin:'0 auto 6px'}}/>
      {children}
    </div>
  </>
);

// ─── Tap-to-action button (primary CTA) ──
const PrimaryCTA = ({children, onClick, style, disabled, icon}) => (
  <button onClick={onClick} disabled={disabled} style={{
    width:'100%',height:54,
    background: disabled ? P.card : P.primary,color:'#fff',border:'none',borderRadius:14,
    fontFamily:F.display,fontWeight:700,fontSize:14,
    letterSpacing:'0.12em',textTransform:'uppercase',
    cursor: disabled ? 'default' : 'pointer',
    display:'flex',alignItems:'center',justifyContent:'center',gap:8,
    opacity: disabled ? 0.5 : 1,
    boxShadow: disabled ? 'none' : `0 8px 24px ${P.primaryGlow}`,
    ...style}}>
    {icon}{children}
  </button>
);

const SecondaryCTA = ({children, onClick, style, icon}) => (
  <button onClick={onClick} style={{
    width:'100%',height:48,
    background:'transparent',color:P.fg,
    border:`1px solid ${P.hairlineStrong}`,borderRadius:14,
    fontFamily:F.body,fontWeight:600,fontSize:14,
    cursor:'pointer',
    display:'flex',alignItems:'center',justifyContent:'center',gap:8,
    ...style}}>
    {icon}{children}
  </button>
);

window.OvShell = {
  StatusBar, HomeIndicator, Avatar, I, Icon, Chip, HeaderBar, Shell,
  BottomSheet, PrimaryCTA, SecondaryCTA,
};
